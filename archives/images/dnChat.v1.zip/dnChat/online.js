// 2002 Glen Murphy : http://glenmurphy.com/ : glen@glenmurphy.com
// This is distributed under the GPL : http://www.gnu.org/copyleft/gpl.html

function Is(){ 
  this.ver=navigator.appVersion;
  this.agent=navigator.userAgent;
  this.dom=document.getElementById?1:0;
  this.opera5=this.agent.indexOf("Opera 5")>-1;
  this.ie5=(this.ver.indexOf("MSIE 5")>-1 && this.dom && !this.opera5)?1:0; 
  this.ie6=(this.ver.indexOf("MSIE 6")>-1 && this.dom && !this.opera5)?1:0;
  this.ie4=(document.all && !this.dom && !this.opera5)?1:0;
  this.ie=this.ie4||this.ie5||this.ie6;
  this.mac=this.agent.indexOf("Mac")>-1;
  this.ns6=(this.dom && parseInt(this.ver) >= 5) ?1:0; 
  this.ns4=(document.layers && !this.dom)?1:0;
  this.bw=(this.ie6||this.ie5||this.ie4||this.ns4||this.ns6||this.opera5);
  return this;
	}

var is = new Is();

function clearusers() {
	users = new Array();
	}
function listuser(name) {
	users[users.length] = name;
	}
function upduserslist() {
	if(users.length > 0) {
		var output = '<b>users in chat</b><br />';
		for(i=0;i<users.length;i++) {
			output += '<br />'+users[i];
			}
		}
	else {
		var output = '<b>click to join chat</b>';
		}
	document.getElementById('gm_users').innerHTML = output;
	}

function endFunc(id) {
	var old = document.getElementById('RS'+id);
	if (old) gm_h.removeChild(old);
	}
function gm_spin() {
	gm_ci++;
	s = document.createElement('script');
	s.src = "f.php?id="+gm_ci+"&cmd=users()";
	s.type = 'text/javascript';
	s.defer = true;
	s.id = 'RS'+gm_ci;
	void(gm_h.appendChild(s));
	setTimeout('gm_spin()',30000);
	}


if(is.dom && !(is.ie && is.mac)) {
	document.write('<div id="gm_users" onclick="window.open(\'chat.php\',\'chat\',\'width=500,height=350,toolbar=no,location=no,directories=no,status=no,menubar=no,resizable=yes,scrollbars=no\');" style="cursor: pointer; cursor: hand; background-color:#F6F6F6; z-index:15; border:1px solid #C6C6C6; padding:2px; width:100px; color:#5E5E5E; font-family:verdana, arial; font-size:10px;"> </div>');	
	var users = new Array();
	var gm_ci;
	var gm_h = document.getElementsByTagName('head').item(0);
	gm_spin();
	}