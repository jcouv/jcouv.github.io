/* 
	Trace.h
*/
#pragma once
#include "StdAfx.h"

#ifndef __TRACE_H__
#define __TRACE_H__

#include <crtdbg.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

#ifdef _DEBUG
#define TRACEMAXSTRING	1024
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

void Trace(HANDLE hFile, const char* format,...);

#define TraceEx Trace

#else
void Trace(0);
void TraceEx(0);
#endif


#endif // __TRACE_H__

