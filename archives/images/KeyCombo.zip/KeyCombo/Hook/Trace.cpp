#pragma once
#include "StdAfx.h"
#include "Trace.h"

#ifdef _DEBUG

void Trace(HANDLE hFile, const char* format,...)
{
	char szBuffer[TRACEMAXSTRING];

	va_list args;
	va_start(args,format);
	int nBuf;
	DWORD bytesWritten;
	nBuf = _vsnprintf(szBuffer,
		TRACEMAXSTRING,
		format,
		args);
	va_end(args);

	_RPT0(_CRT_WARN,szBuffer); // Write to debug console

	// Write to log file
	if (hFile != NULL) {
		char newline = '\n';
		char br[5] = "<br>";
		WriteFile(hFile, szBuffer, nBuf, &bytesWritten, NULL);
		WriteFile(hFile, br, 4*sizeof(char), &bytesWritten, NULL);
	}
}
#else
#pragma message("Tracing disabled in this build")
#endif
