// Hook.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "Trace.h"
#define DllExport __declspec( dllexport )

// Global variables
HINSTANCE hInstance = NULL;		// This instance of the DLL
HHOOK hKeyboardHook = NULL;		// Handle to keyboard filter hook

BOOL spacePressed = FALSE;		// Is the space key held down? // May be replace with getAsyncKeyState
DWORD spacePressedTime = 0;		// Last time space was pressed, if no key was pressed afterward

// Forward declarations
void printWMType(WPARAM wParam);
LRESULT CALLBACK KeyboardFilter(int nCode, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK state1Handler(int nCode, WPARAM wParam, LPARAM lParam);
bool spaceHandler(WPARAM wParam, LPARAM lParam);
bool revertHandler(int nCode, WPARAM wParam, LPARAM lParam);


BOOL APIENTRY DllMain(HANDLE hModule, 
                      DWORD  ul_reason_for_call, 
                      LPVOID lpReserved)
{
	// Find out why we're being called
	switch (ul_reason_for_call) {

	case DLL_PROCESS_ATTACH:
		TraceEx(NULL, "MouseHooks : Hook DLL loaded\n");
		hInstance = (HINSTANCE) hModule;
		return TRUE;

	case DLL_PROCESS_DETACH:
		TraceEx(NULL, "MouseHooks : Hook DLL unloaded\n");
		return TRUE;

	default:
		return TRUE;
	}
}

// Routine to start and stop local keyboard message filtering
DllExport BOOL SetKeyboardFilterHook(BOOL activate)
{
	if (activate)
	{
		if (hKeyboardHook == NULL)
		{
			// Start up the hook...
			hKeyboardHook = SetWindowsHookEx(
				WH_KEYBOARD_LL,				// Hook in before msg reaches app
				(HOOKPROC) KeyboardFilter,  // Hook procedure
				hInstance,                  // This DLL instance
				0L                          // Hook in to all apps
				);
			if (hKeyboardHook == NULL) {
				return FALSE;
			}
		}
		return TRUE;
	} else {
		// Unhook
		if (hKeyboardHook != NULL)
		{
			// Stop the hook...
			if (!UnhookWindowsHookEx(hKeyboardHook)) {
				return FALSE;
			}
			hKeyboardHook = NULL;
		}
		return TRUE;
	}
}

void printWMType(WPARAM wParam) {
	switch (wParam) {
		case WM_KEYDOWN:  
			TraceEx(NULL, "WM_KEYDOWN");
			break;
		case WM_SYSKEYDOWN:
			TraceEx(NULL, "WM_SYSKEYDOWN");
			break;
		case WM_KEYUP:    
			TraceEx(NULL, "WM_KEYUP");
			break;
		case WM_SYSKEYUP: 
			TraceEx(NULL, "WM_SYSKEYUP");
			break;
	}
}

// Keyboard Hook
LRESULT CALLBACK KeyboardFilter(int nCode, WPARAM wParam, LPARAM lParam)
{
	PKBDLLHOOKSTRUCT p = (PKBDLLHOOKSTRUCT) lParam;

	if (nCode < 0 || 
		nCode != HC_ACTION ||
		(p->flags & LLKHF_INJECTED)) 
	{
		return CallNextHookEx(hKeyboardHook, nCode, wParam, lParam);
	}

    if (spaceHandler(wParam, lParam)) {
        return 1;
    }
    if (revertHandler(nCode, wParam, lParam)) {
        return 1;
    }

    return CallNextHookEx(hKeyboardHook, nCode, wParam, lParam);
}


bool spaceHandler(WPARAM wParam, LPARAM lParam) {
	PKBDLLHOOKSTRUCT p = (PKBDLLHOOKSTRUCT) lParam;

	// Space down handling
	if (wParam == WM_KEYDOWN && p->vkCode == VK_SPACE) {
		// On first space press set onlySpacePressed
		if (spacePressed == FALSE) { spacePressedTime = GetCurrentTime(); }

		spacePressed = TRUE;
		return true;
	}

	// Space up handling
	if (wParam == WM_KEYUP && p->vkCode == VK_SPACE) {
		// Only space was pressed, print a space
		if (spacePressedTime != 0) {
			keybd_event(VK_SPACE, 0, 0, 0);
			keybd_event(VK_SPACE, 0, KEYEVENTF_KEYUP, 0);
		}

		spacePressedTime = 0;
		spacePressed = FALSE;
		return true;
	}

	return false; // This was not a SPACE UP|DOWN
}

bool revertHandler(int nCode, WPARAM wParam, LPARAM lParam) {
	PKBDLLHOOKSTRUCT p = (PKBDLLHOOKSTRUCT) lParam;
    BYTE replaceWith;

    if (!spacePressed) { return false; } // Key was not reverted
    
	// a key other than SPACE was pressed
	spacePressedTime = 0;

    switch (p->vkCode) {
    case 'Q':
		replaceWith = 'P'; // this replaces SPACE+Q with a P
        break;

	// the rest of the combinations have been "neutered" to avoid trouble with Mattias Corps
    case 'W':
        replaceWith = 'W'; // the 
        break;
    case 'E':
        replaceWith = 'E';
        break;
    case 'R':
        replaceWith = 'R';
        break;
    case 'T':
        replaceWith = 'T';
        break;
    case 'A':
        replaceWith = 'A';
        break;
    case 'S':
        replaceWith = 'S';
        break;
    case 'D':
        replaceWith = 'D';
        break;
    case 'F':
        replaceWith = 'F';
        break;
    case 'G':
        replaceWith = 'G';
        break;
    case 'Z':
        replaceWith = 'Z'; 
        break;
    case 'X':
        replaceWith = 'X';
        break;
    case 'C':
        replaceWith = 'C';
        break;
    case 'V':
        replaceWith = 'M';
        break;
    case 'B':
        replaceWith = 'N';
        break;
    case VK_CAPITAL: // Send a return (VK_RETURN)
        replaceWith = VK_RETURN;
        break;
    case VK_TAB: // Send a backspace (VK_BACK)
        replaceWith = VK_TAB;
        break;
    case '1': // Open the browser
        replaceWith = VK_BROWSER_HOME;
        break;
    case VK_ESCAPE: // Will stop the hook
        SetKeyboardFilterHook(FALSE);
        return false;

    case 'K': // Arrow down
        replaceWith = VK_DOWN;
        break;
    case 'L': // Arrow right
        replaceWith = VK_RIGHT;
        break;
    case 'J': // Arrow left
        replaceWith = VK_LEFT;
        break;
    case 'I': // Arrow up
        replaceWith = VK_UP;
        break;
    case 0xBA: // Semi-column replaced with page down
        replaceWith = 0x22;
        break;
    case 'P': // Page up
        replaceWith = 0x21;
        break;
    default:
        TraceEx(NULL, "Keycode 0x%x\n", p->vkCode);
        return false;
    }

    if (wParam == WM_KEYDOWN) {
		keybd_event(replaceWith, 0, 0, 0);
	} 
	if (wParam == WM_KEYUP) {
		keybd_event(replaceWith, 0, KEYEVENTF_KEYUP, 0);
    }
    
	return true; // The key was reverted
}

/*
	if (wParam == WM_KEYDOWN || wParam == WM_KEYUP) {
		TraceEx(NULL, "Virtual Key Code = %i\n", p->vkCode);
		onlySpacePressed = FALSE;
		if (p->vkCode == 65) {
			p->vkCode = 71;

			if (wParam == WM_KEYDOWN) {
				keybd_event(0x47, 0, 0, 0);
			} 
			if (wParam == WM_KEYUP) {
				keybd_event(0x47, 0, KEYEVENTF_KEYUP, 0);
			}

			return 1;
		}
	}
*/
