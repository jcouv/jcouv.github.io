// created on 10/19/2002 at 11:06 PM
// copyright Julien D. Couvreur

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

// TODO:
// Legend: * easy, ** medium, *** difficult
// 

namespace DumkyNamespace 
{

	public class SelectorPlusControl : SelectorControl {
		public event ContextMenuClickHandler ContextClick;
		private string contextMenuUniqueID;
		private string copyright = @"<!-- SelectorPlus web control provided by Dumky. Check out http://code.monstuff.com/ -->";

		//******* RENDERING *********//
		protected override void OnPreRender (EventArgs e) {
			base.OnPreRender(e);
			if (!Page.IsClientScriptBlockRegistered("SelectorPlusMainScript")) {
				Page.RegisterClientScriptBlock("SelectorPlusMainScript", plusscript);
			}
		}
		
		// write out the table with the labels and the hidden field
		protected override void Render(HtmlTextWriter output) {
			base.Render(output);
			output.Write(plusstartupscript, UniqueID, contextMenuUniqueID);
			output.Write(copyright);
		}
		
		//******* POST-BACK HANDLING *******//
		// When __doPostBack client-side function is called
		public override void RaisePostBackEvent(string eventArgument){
			System.Web.HttpContext.Current.Trace.Write("post back:" + eventArgument);
			if (!eventArgument.StartsWith("contextmenu:")) {
				base.RaisePostBackEvent(eventArgument);
			} else {
				if (ContextClick != null) {
					ContextClick(this, new ContextMenuClickEventArgs(eventArgument));
				}
			}
		}
		
		//******* UTILITY FUNCTIONS ********//
		public void Initialize(string[] labels, string contextMenuUniqueID) {
			base.Initialize(labels);
			this.contextMenuUniqueID = contextMenuUniqueID;
		}

		public override void Initialize(string[] labels) {
			// forbidden
			// throw exception
		}
		
		//******* PRIVATE STRINGS ********//
		// Binds all the event handlers
        private static readonly string plusstartupscript =
@"<script language=""javascript""> SelectorPlus_registerEvents(""{0}"", ""{1}""); </script>";
		
        // Main script: contains all the event handling logic.
        // May be shared accross multiple Selector controls
        // Will be moved into a separate file (using a remote javascript include)?
		private static readonly string plusscript = 
@"<script language=""javascript"">
// SelectorPlus support functions

function SelectorPlus_on_context(e) {
	var targetID =  Selector_getControlID(this);
	var container = document.getElementById(targetID+""-container"");	
	var menuID = container.attributes.getNamedItem(""_menuid"").value; 
	var contextToken = this.attributes.getNamedItem(""_index"").value;
	
	Selector_change(this, true); Selector_buildHiddenField(targetID); 
	
	return ContextMenu_show(e, menuID, targetID, contextToken)
}

function SelectorPlus_registerEvents(controlID, menuID) {
	foobar(""registerEvents "" + controlID);
	
	// Go through the selection elements
	for (var index = 0; index>=0; index++) {
		var tmp = document.getElementById(controlID+""-""+index);
		if (!tmp) { break; } // We have reached the end of the loop.
        
        // register all the events for one element
		tmp.oncontextmenu = SelectorPlus_on_context;
	}
	
	var container = document.getElementById(controlID+""-container"");
	var menuIdAttr= document.createAttribute(""_menuid"");
	menuIdAttr.value = menuID;
	container.attributes.setNamedItem(menuIdAttr);
}
</script>
";
	}
}
