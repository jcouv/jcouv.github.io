using DumkyNamespace;
using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;

public class WebForm1 : System.Web.UI.Page 
{
	protected DumkyNamespace.SelectorPlusControl MySelector1;
	protected DumkyNamespace.ContextMenuControl MyContextMenu1;
	protected Label Label1;
	
	private void Page_Load(object sender, System.EventArgs e)
	{
		string [] labels = { "test0", "test1", "test2", "test3", "test4", "test5" };

		MySelector1.Initialize(labels, MyContextMenu1.UniqueID);
			 
		MySelector1.DoubleClick += new DoubleClickHandler(this.Selector_DblClick);
		MySelector1.SelectionChange += new EventHandler(this.Selector_Change);
		MySelector1.ContextClick += new ContextMenuClickHandler(this.SelectorContext_Click);
		MyContextMenu1.Click += new ContextMenuClickHandler(this.ContextMenu_Click);
		
		Entry [] items = { 
			new Entry("label1"),
			new TargetPostBackEntry("label2", "label2_click"),
			new CustomMethodEntry("label3", "label3_method"),
			new CustomMethodEntry("close", "ContextMenu_hideCustomMethod")
		};

		MyContextMenu1.Initialize(items);
	}
	
	public void Selector_DblClick(object sender, DoubleClickEventArgs args) {
		Trace.Write("double click = " + args.selectedIndex);
	}
	
	public void Selector_Change(object sender, EventArgs args) {
		Trace.Write("selection changed");
	}
	
	public void ContextMenu_Click(object sender, ContextMenuClickEventArgs args) {
		Trace.Write("menu click = [target:"+args.target+"] [context:"+args.context+"] [index:"+args.index+"]");
	}
	
	public void SelectorContext_Click(object sender, ContextMenuClickEventArgs args) {
		Trace.Write("selector context click = [context:"+args.context+"] [context:"+args.action+"] [index:"+args.index+"]");
	}
}
