// created on 10/21/2002 at 11:06 PM
// copyright Julien D. Couvreur

using System;
//using System.Collections;
using System.Collections.Specialized;
//using System.Text;


namespace DumkyNamespace {
	
	public class QueryStringParser {
		public static NameValueCollection Parse(string input) {
			string[] pairs = input.Split('&');
			NameValueCollection result = new NameValueCollection();
			
			foreach (string pair in pairs) {
				string[] namevalue = pair.Split('=');
				if (namevalue.Length != 2) {
					throw new Exception("parse error");
				}
				result.Add(namevalue[0], namevalue[1]);	
			}
			return result;
		}
	}
}
