// created on 8/17/2002 at 11:06 PM
// copyright Julien D. Couvreur

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;

// TODO:
// Legend: * easy, ** medium, *** difficult
// 1. (**) allow the script to live in a remote .js file (optionally), served by the Selector itself
// 2. (**) use ondblclick and onserverdblclick, to allow both
// 3. (*) make the post-back on double-click optional
// 4. remove the two global javascript variables
// 5. (**) during the submit: block selection changes
// 6. (***) make the control accessible via keyboard
// 7. (*) make control integrated in VS 

namespace DumkyNamespace 
{
	public class DoubleClickEventArgs : EventArgs {
		protected int _selectedIndex; 
		
		public int selectedIndex {
			get { return _selectedIndex; }
		}
		
		public DoubleClickEventArgs(int index) {
			_selectedIndex = index;
		}
	}
	
	public delegate void DoubleClickHandler(object sender, DoubleClickEventArgs args);
	
	public class SelectorControl : System.Web.UI.WebControls.WebControl, IPostBackDataHandler, IPostBackEventHandler {
		public bool[] selections = new bool[0];
		private string[] labels = new string[0];
		public event DoubleClickHandler DoubleClick;
		public event EventHandler SelectionChange;
		public bool Debug = false;
		public string cssTableClassName = "selector";
		public string cssSelectedClassName = "selected";
		public string cssNotSelectedClassName = "notselected";
		private readonly string copyright = @"<!-- Selector web control provided by Dumky. Check out http://code.monstuff.com/ -->";
		
		//******* STATE MANAGEMENT *******//
		protected override void LoadViewState(object savedState) 
		{
			base.LoadViewState(savedState);
			selections = (bool[]) ViewState["SelectionList"];
		}

		protected override object SaveViewState()
		{  
			ViewState["SelectionList"] = selections;
		   	return base.SaveViewState();
		}

		//******* RENDERING *********//
		protected override void OnPreRender (EventArgs e) {
			if (!Page.IsClientScriptBlockRegistered("SelectorMainScript")) {
				Page.RegisterClientScriptBlock("SelectorMainScript", script);
			}
		}
		
		// write out the table with the labels and the hidden field
		protected override void Render(HtmlTextWriter output) {
			output.Write(header, UniqueID, cssTableClassName);
			
			// render middle part
			for (int index = 0; index < selections.Length; index++) {
				output.Write(repeater, 
				             UniqueID,
				             index, 
				             labels[index], 
				             selections[index] ? cssSelectedClassName : cssNotSelectedClassName);
			}
		    
			output.Write(footer, 
			             UniqueID,
			             SelectionToString());
			
			if (Debug) { 
				output.Write(debugscript); 
			} else { 
				output.Write(nondebugscript); 
			} // TODO: cleanup
			
			output.Write(startupscript, UniqueID, cssSelectedClassName, cssNotSelectedClassName);
			output.Write(copyright);
			
			Page.GetPostBackEventReference(this); // ensure the doPostBack method is in the form
		}
		
		//******* POST-BACK HANDLING *******//
		// load the form data posted back by the control
		public bool LoadPostData(string postDataKey, NameValueCollection postData) {
			string formField = (string) postData[UniqueID];
			bool selectionChanged = false;
			
			// parse form data
		    string[] formSelections = formField.Split(';');			
			
			// update selection and detect any change
			for (int index = 0; index < selections.Length; index++) {
				// was this entry selected in the form?
				bool selected = (Array.IndexOf(formSelections, index.ToString()) != -1);
				
				// did the selection of this entry change?
				if (selections[index] != selected) {
					// remember at least one entrie's selection changed
					selectionChanged = true;
					selections[index] = selected;
				}
			}
			return selectionChanged;
		}
		
		// what is this for?!
		public void RaisePostDataChangedEvent() {
			if (SelectionChange != null) {
				SelectionChange(this, new EventArgs());
			}
			return;
		}
		
		// When __doPostBack client-side function is called
		public virtual void RaisePostBackEvent(string eventArgument){
			//System.Web.HttpContext.Current.Trace.Write("post back:" + eventArgument);
			int index = int.Parse(eventArgument);
			if (DoubleClick != null) {
				DoubleClick(this, new DoubleClickEventArgs(index));
			}
			return;
		}

		
		//******* UTILITY FUNCTIONS ********//
		// Load labels into the Selector
		public virtual void Initialize(string[] labels) {
			if (selections.Length != labels.Length) {
				selections = new bool[labels.Length];
			}
			this.labels = labels;
			
			// TODO: check selections length against labels length. if error, reset selections
		}
		
		// Build a ; separated list of the selected indexes
		public string SelectionToString() {
			StringBuilder result = new StringBuilder();
			
			for (int index = 0; index < selections.Length; index++) {
				if (selections[index]) {
					if (result.Length != 0) { result.Append(";"); }
					result.Append(index.ToString());
				}
			}
			return result.ToString();
		}
		
		//******* PRIVATE STRINGS ********//
		// Opening table
		private static readonly string header = 
		@"<div id=""{0}-container"" class=""{1}"">
";

		// Row with a label
		private static readonly string repeater = 
		@"<div id=""{0}-{1}"" class=""{3}"">{2}</div>
";
		
		// Closing table and hidden form field
		private static readonly string footer = 
@"</div>
<input type=""hidden"" id=""{0}"" name=""{0}"" value=""{1}""/>
";
		 
		// Binds all the event handlers
        private static readonly string startupscript =
@"<script language=""javascript""> Selector_registerEvents(""{0}"", ""{1}"", ""{2}""); </script>";
		
		// Needs to be made flexible (no hardcoded field name :-)
		private static readonly string debugscript =
@"<script language=""javascript"">
function foobar(text) {
  var output = document.getElementById(""output"");
  output.innerHTML += text + ""   ---\n"";
}
</script>
<div id=""output"" border=""1""></div>
";

		private static readonly string nondebugscript =
@"<script language=""javascript"">
function foobar(text) { }
</script>
";			

        // Main script: contains all the event handling logic.
        // May be shared accross multiple Selector controls
        // Will be moved into a separate file (using a remote javascript include)?
		public static readonly string script = 
@"<script language=""javascript"">
// Selector control functions

// Are defined globally, but is safe because you can't have the mouse down in 2 Selector controls at once...
var isMouseDown = false; // Is the mouse button held down?
var isSelecting = true; // Only meaningfull when mouse is down

// Called when the mouse button is pressed
function Selector_on_down(event) {
  foobar(""down"");

  isMouseDown = true;
  isSelecting = Selector_toggle(this);

  Selector_buildHiddenField(Selector_getControlID(this));
	
  return false;
}

// Called when you hover over a label
function Selector_on_over(event) {
  foobar(""over:"" + isMouseDown + ""-"" + isSelecting);

  if (isMouseDown == false) return false;

  var originalClassName = this.className;
  if (isMouseDown && isSelecting) {
    this.className = Selector_getSelectedCSS(this);
  }
  if (isMouseDown && !isSelecting) {
    this.className = Selector_getUnselectedCSS(this);
  }
  if (this.className != originalClassName) 
  	Selector_buildHiddenField(Selector_getControlID(this));
	
  return false;
}

// Called when you unpress the mouse button or if the mouse leaves the containing table
function Selector_on_up(event) {	
  foobar(""up "");
  var controlID = Selector_getControlID(this);
  if (isMouseDown) {
	isMouseDown = false;
  } 

  return false;
}

// Called when you double click on a label
function Selector_on_dbl(event){
  foobar(""double"");
  var controlID = Selector_getControlID(this);
  var selectedIndex = this.attributes.getNamedItem(""_index"").value;

  // TODO: Improve extra click cancellation (use hidden field to restore selections upon load?)
  if (window.event) { Selector_toggle(this); Selector_buildHiddenField(controlID); } // For IE, cancel the first (extra) click
  
  __doPostBack(controlID, selectedIndex);

  return false;
}

function Selector_on_false() { return false; }

// Toggle one element
// Returns whether we are selecting or de-selecting
function Selector_toggle(element) {
  var classSel = Selector_getSelectedCSS(element);
  var classNotSel = Selector_getUnselectedCSS(element);
  if (element.className == classSel) {
    element.className = classNotSel;
  	return false;
  } else {
    element.className = classSel;
  	return true;
  }
}

// Select/Unselect one element
function Selector_change(element, select) {
  var classSel = Selector_getSelectedCSS(element);
  var classNotSel = Selector_getUnselectedCSS(element);
  if (select) {
    element.className = classSel;
  } else {
    element.className = classNotSel;
  }
}

// Store the new selection into the hidden field
function Selector_buildHiddenField(controlID) {
	var result = """";
	foobar(""buildHiddenField "" + controlID);
	for (index = 0; index>=0; index++) {
		var tmp = document.getElementById(controlID+""-""+index);
		if (!tmp) { break; } // We have reached the end of the loop.
		if (tmp.className == ""selected"") {
			if (result != """") { result += "";""; }
			result += index;
		}
	}
	
	foobar(""Selection is "" + result);
	tmp = document.getElementById(controlID);
	if (tmp) { tmp.value = result; }
	selectionChanged = false;
}

// Get the UniqueID associated with this control
function Selector_getControlID(element) {
  return element.attributes.getNamedItem(""_id"").value;
}

function Selector_getSelectedCSS(element) {
  return document.getElementById(Selector_getControlID(element)+""-container"").attributes.getNamedItem(""_selectedCSS"").value;
}

function Selector_getUnselectedCSS(element) {
  return document.getElementById(Selector_getControlID(element)+""-container"").attributes.getNamedItem(""_unselectedCSS"").value;
}

function Selector_registerEvents(controlID, selectedCSS, unselectedCSS) {
	foobar(""registerEvents "" + controlID);
	
	// Go through the selection elements
	for (var index = 0; index>=0; index++) {
		var item = document.getElementById(controlID+""-""+index);
		if (!item) { break; } // We have reached the end of the loop.
        
        // register all the events for one element
		item.onmousedown = Selector_on_down;
		item.onmouseup = Selector_on_up;
		item.onmouseover = Selector_on_over;
		
		// Disable text selection in IE
		item.onselectstart = Selector_on_false;
		 
		if (item.addEventListener)
		  // Workaround for Mozilla bug
		  // http://bugzilla.mozilla.org/show_bug.cgi?id=90459
		  item.addEventListener(""dblclick"", Selector_on_dbl, false);
		else
		  item.ondblclick = Selector_on_dbl;
		
		var _id = document.createAttribute(""_id"");
		_id.value = controlID;
		item.attributes.setNamedItem(_id);
		
		var _index = document.createAttribute(""_index"");
		_index.value = index;
		item.attributes.setNamedItem(_index);
	}

    // Disable text selection in Mozilla
    var container = document.getElementById(controlID+""-container"");
    container.onmousedown = Selector_on_false;
	
	var _selectedCSS = document.createAttribute(""_selectedCSS"");
	_selectedCSS.value = selectedCSS;
	container.attributes.setNamedItem(_selectedCSS);
	
	var _unselectedCSS = document.createAttribute(""_unselectedCSS"");
	_unselectedCSS.value = unselectedCSS;
	container.attributes.setNamedItem(_unselectedCSS);
}
</script>
";
	}
}
