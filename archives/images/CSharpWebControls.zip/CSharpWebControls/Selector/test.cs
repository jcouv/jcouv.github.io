using DumkyNamespace;
using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;

public class WebForm1 : System.Web.UI.Page 
{
	protected DumkyNamespace.SelectorControl MySelector1;
	protected DumkyNamespace.SelectorControl MySelector2;
	protected Label Label1;
	
	private void Page_Load(object sender, System.EventArgs e)
	{
		string [] labels = { "test0", "test1", "test2", "test3", "test4", "test5" };

		MySelector1.Initialize(labels);
			 
		
		MySelector1.DoubleClick += new DoubleClickHandler(this.Selector_DblClick);
		MySelector1.SelectionChange += new EventHandler(this.Selector_Change);
	}
	
	public void Selector_DblClick(object sender, DoubleClickEventArgs args) {
		Trace.Write("double click = " + args.selectedIndex);
	}
	
	public void Selector_Change(object sender, EventArgs args) {
		Trace.Write("selection changed");
	}
}
