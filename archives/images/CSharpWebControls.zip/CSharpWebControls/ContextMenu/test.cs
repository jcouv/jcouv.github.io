using DumkyNamespace;
using System;
using System.Collections;
using System.Web.UI;
using System.Web.UI.WebControls;

public class WebForm1 : System.Web.UI.Page 
{
	protected DumkyNamespace.ContextMenuControl MyContextMenu1;
	protected Label Label1;
	
	private void Page_Load(object sender, System.EventArgs e)
	{
		Entry [] items = { 
			new Entry("label1"),
			new TargetPostBackEntry("label2", "label2_click"),
			new CustomMethodEntry("label3", "label3_method")
		};

		MyContextMenu1.Initialize(items);
			 
	}
	
}
