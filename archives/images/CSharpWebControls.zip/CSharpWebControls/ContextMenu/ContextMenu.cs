// created on 10/17/2002 at 11:06 PM
// copyright Julien D. Couvreur

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web;

// TODO:
// Legend: * easy, ** medium, *** difficult
// 1. Title "entry"
// 2. Close Menu "entry"
// 4. Make the menu close itself with various timeouts

namespace DumkyNamespace 
{	
	public class Entry {
		// Post back to the ContextMenu control
		public string menuLabel;
		
		public Entry(string menuLabel) {
			this.menuLabel = menuLabel;
		}
		
		public virtual string getCommand() { return ""; }
	}
	
	public class TargetPostBackEntry : Entry {
		// Post back to the target control
		public string actionToken;
		
		public TargetPostBackEntry(string menuLabel, string actionToken) : base(menuLabel) {			
			this.actionToken = actionToken;
		}
		
		public override string getCommand() { return "_action=\"" + HttpUtility.UrlEncode(actionToken) + "\""; }
	}
	
	public class CustomMethodEntry : Entry {
		// Call a custom client-side method
		public string methodName;
		
		public CustomMethodEntry(string menuLabel, string methodName) : base(menuLabel) {
			this.methodName = methodName;
		}
		
		public override string getCommand() { return "_method=\"" + HttpUtility.UrlEncode(methodName) + "\""; }
	}
	
	public class ContextMenuClickEventArgs : EventArgs {
		public readonly NameValueCollection pairs;
		public int index {
			get { return int.Parse(GetValue("menu")); }
		}
		public string target {
			get { return GetValue("target"); }
		}
		public string context {
			get { return GetValue("context"); }
		}
		public string action {
			get { return GetValue("action"); }
		}
		
		public ContextMenuClickEventArgs(string eventArgument) {
			const string prefix = "contextmenu:";
			if (!eventArgument.StartsWith(prefix)) {
				System.Web.HttpContext.Current.Trace.Write("parse error");
			}
			pairs = QueryStringParser.Parse(eventArgument.Remove(0, prefix.Length));
		}
		
		public string GetValue(string key) {
			string[] values = pairs.GetValues(key);
			if (values == null) {
				return "";
			} else {
				return values[0];
			}
		}
	}
	
	public delegate void ContextMenuClickHandler(object sender, ContextMenuClickEventArgs args);
	
	public class ContextMenuControl : System.Web.UI.WebControls.WebControl, IPostBackEventHandler {
		public event ContextMenuClickHandler Click;
		public Entry[] items = new Entry[0];
		public string cssContainerClassName = "contextmenu";
		public string cssSelectedClassName = "menuselected";
		public string cssNotSelectedClassName = "menunotselected";
		private string copyright = @"<!-- Selector web control provided by Dumky. Check out http://code.monstuff.com/ -->";		

		//******* RENDERING *********//
		protected override void OnPreRender (EventArgs e) {
			if (!Page.IsClientScriptBlockRegistered("ContextMenuMainScript")) {
				Page.RegisterClientScriptBlock("ContextMenuMainScript", script);
			}
		}

		// write out the table with the labels and the hidden field
		protected override void Render(HtmlTextWriter output) {
			output.Write(header, UniqueID, cssContainerClassName);
			
			// render middle part
			for (int index = 0; index < items.Length; index++) {
				output.Write(repeater, 
				             UniqueID,
				             index,
				             cssNotSelectedClassName,
				             items[index].getCommand(),
				             items[index].menuLabel);
			}
			
			output.Write(footer);
			output.Write(startupscript, UniqueID, cssSelectedClassName, cssNotSelectedClassName);
			output.Write(copyright);
			
			Page.GetPostBackEventReference(this); // ensure the doPostBack method is in the form
		}
		

		//******* POST-BACK HANDLING *******//
		// When __doPostBack client-side function is called
		public void RaisePostBackEvent(string eventArgument){
			System.Web.HttpContext.Current.Trace.Write("post back:" + eventArgument);
					
			if (Click != null) {
				Click(this, new ContextMenuClickEventArgs(eventArgument));
			}
			
			return;
		}
		
		//******* UTILITY FUNCTIONS ********//
		// Load labels into the ContextMenu
		public void Initialize(Entry[] items) {
			this.items = items;
		}
		
		//******* PRIVATE STRINGS ********//
		// Opening table
		private static readonly string header = 
		@"<div id=""{0}-container"" class=""{1}"">
";
		
		private static readonly string repeater =
		@"<div id=""{0}-{1}"" class=""{2}"" {3}>{4}</div>
";
		
		private static readonly string footer =
		@"</div>
";

		// Binds all the event handlers
        private static readonly string startupscript =
@"<script language=""javascript""> ContextMenu_registerEvents(""{0}"", ""{1}"", ""{2}""); </script>";


		private static readonly string script = 
@"<script language=""javascript"">
// ContextMenu support functions

function ContextMenu_show(e, menuID, targetID, contextToken) {
	if (!e) e = event; // IE doesn't pass the event properly
	
	var contextMenu = document.getElementById(menuID + ""-container"");
	
	var rightedge = document.body.clientWidth - e.clientX;
	var bottomedge = document.body.clientHeight - e.clientY;
	
	//if the horizontal distance isn't enough to accomodate the width of the context menu
	if (rightedge < contextMenu.offsetWidth) {
		//move the horizontal position of the menu to the left by it's width
		contextMenu.style.left = document.body.scrollLeft + e.clientX - contextMenu.offsetWidth;
	} else {
		//position the horizontal position of the menu where the mouse was clicked
		contextMenu.style.left = document.body.scrollLeft + e.clientX
	}
	
	//same concept with the vertical position
	if (bottomedge < contextMenu.offsetHeight) {
		contextMenu.style.top = document.body.scrollTop + e.clientY - contextMenu.offsetHeight;
	} else {
		contextMenu.style.top = document.body.scrollTop + e.clientY;
	}
	
	if (targetID) {
		var targetAttr = document.createAttribute(""_target"");
		targetAttr.value = targetID;
		contextMenu.attributes.setNamedItem(targetAttr);
	}
	
	if (contextToken) {
		var contextAttr = document.createAttribute(""_context"");
		contextAttr.value = contextToken;
		contextMenu.attributes.setNamedItem(contextAttr);
	}
	
	contextMenu.style.visibility = ""visible"";
	return false;
}

function ContextMenu_hide(menuID) {
	var contextMenu = document.getElementById(menuID + ""-container"");
	contextMenu.style.visibility = ""hidden"";
	return false;
}

function ContextMenu_hideCustomMethod(event, menuitem) {
	ContextMenu_hide(menuItem.attributes.getNamedItem(""_id"").value);
	return false;
}

function ContextMenu_on_over(e) {
	var menuItem = getMenuItem(e);

	var containerID = menuItem.attributes.getNamedItem(""_id"").value + ""-container"";
	var selectedCSS = document.getElementById(containerID).attributes.getNamedItem(""_selectedCSS"").value;
	menuItem.className = selectedCSS;
}

function ContextMenu_on_out(e) {
	var menuItem = getMenuItem(e);
	
	var containerID = menuItem.attributes.getNamedItem(""_id"").value + ""-container"";
	var unselectedCSS = document.getElementById(containerID).attributes.getNamedItem(""_unselectedCSS"").value;
	menuItem.className = unselectedCSS;
}

function ContextMenu_on_click(e) {
	if (!e) e = event; // IE doesn't pass the event properly	
	var menuItem = getMenuItem(e);
	
	var _actionAttr = menuItem.attributes.getNamedItem(""_action"");
	var _methodAttr = menuItem.attributes.getNamedItem(""_method"");
	var _id = menuItem.attributes.getNamedItem(""_id"").value;
	var container = document.getElementById(_id + ""-container"")
	var _target = container.attributes.getNamedItem(""_target"").value;
	var _context = container.attributes.getNamedItem(""_context"").value;
	var _index = menuItem.attributes.getNamedItem(""_index"").value;

	// Don't forget to use _action.value and _method.value ;-)
	if (_actionAttr) {
		// Post back to the target control
		var argument = ""contextmenu:context=""+ _context +""&action=""+ _actionAttr.value + ""&menu=""+ _index;
		// TODO: add urlencoding
		__doPostBack(_target, argument);
	} else if (_methodAttr) {
		// Call a custom javascript method
		ContextMenu_hide(_id);
		return eval(""""+ _methodAttr.value +""(e, menuItem)"");	
	} else {
		// Post back to the ContextMenu control
		__doPostBack(_id, ""contextmenu:target=""+ _target +""&context=""+ _context +""&menu=""+ _index);
		// return ?
	}
	
	return false;
}

function ContextMenu_on_false() { return false; }

function getMenuItem(e) {
	if (!e) e = event; // IE doesn't pass the event properly	
	var menuItem = e.currentTarget;
	if (!menuItem) menuItem = event.srcElement;
	return menuItem;
}

function ContextMenu_registerEvents(controlID, selectedCSS, unselectedCSS) {
	// Go through the menu items
	for (var index = 0; index>=0; index++) {
		var item = document.getElementById(controlID+""-""+index);
		if (!item) { break; } // We have reached the end of the loop.

		// register all the events for one element
		item.onclick = ContextMenu_on_click;
		item.onmouseover = ContextMenu_on_over;
		item.onmouseout = ContextMenu_on_out;

		// Disable text selection in IE
		item.onselectstart = ContextMenu_on_false;
		
		var _id = document.createAttribute(""_id"");
		_id.value = controlID;
		item.attributes.setNamedItem(_id);
		
		var _index = document.createAttribute(""_index"");
		_index.value = index;
		item.attributes.setNamedItem(_index);
	}

	// Disable text selection in Mozilla
	var container = document.getElementById(controlID+""-container"");
	container.onmousedown = ContextMenu_on_false;
	
	var _selectedCSS = document.createAttribute(""_selectedCSS"");
	_selectedCSS.value = selectedCSS;
	container.attributes.setNamedItem(_selectedCSS);
	
	var _unselectedCSS = document.createAttribute(""_unselectedCSS"");
	_unselectedCSS.value = unselectedCSS;
	container.attributes.setNamedItem(_unselectedCSS);
	
	var _target = document.createAttribute(""_target"");
	_target.value = """";
	container.attributes.setNamedItem(_target);
	
	var _context = document.createAttribute(""_context"");
	_context.value = """";
	container.attributes.setNamedItem(_context);
}

</script>
";
		
	}
}

//* Documentation
// Javascript API:
// 		ContextMenu_show(UniqueID1, UniqueID2, contextstring, event)
// 			Displays the menu.
// 			UniqueID1 is the id of the ContextMenu to display.
//			UniqueID2 is the id of the target control. Only used when the menu posts back to the target control.
//			contextstring indicates in what context of the target control the menu is opened.
//			event is the mouse event used to position the menu when it gets displayed.
//
//		ContextMenu_hide(UniqueID1)
//			Hides the menu with id UniqueID1.
//
//		ContextMenu_hideCustomMethod(event, menuitem)
//			Hides the menu that holds the menuitem. Provides for use in a CustomMethodEntry
//
// ASP.NET API:
//		Initialize
//
//		<event handlers>
//
//
// Types of entries:
// 		Entry
// 			Default entry type in the context menu.
//			Posts back to the context menu control when clicked.
//			__doPostBack(<menu id>, ""contextmenu:target=<target id>&context=<contextstring>&menu=<index>)
//
// 		TargetPostBackEntry 
//			Posts back to the target ASP.NET control, to which the context menu is associated, with:
//			__doPostBack(<target id>, "contextmenu:context=<contextstring>&action=<action>&menu=<index>)
//
// 		CustomMethodEntry
//			Calls a custom client-side method that implements the following interface:
//			custommethod(event, menuitem)
//			where event is the mouse click event on the context menu,
//			and menuitem is the entry that received the event
//
//
// Client-side data structure:
//		menu-container
//			Container div.
//			Has the following attributes set:
//			id=<UniqueID>-container
//			class=<cssContainerClassName>
//			_selectedCSS=<cssSelectedClassName>
//			_unselectedCSS=<cssNotSelectedClassName>
//			_target (id of the target control)
//			_context (context in which the menu was diplayed, in the target control)
//
//		menuitem
//			Menu entry div.
//			Has the following attributes set:
//			id=<UniqueID>-<entry index>
//			class=<cssSelectedClassName> or <cssNotSelectedClassName>
//			_id=<UniqueID>
//			_index=<entry index>
//			_action=<action token>, used by TargetPostBack entries
//			_method=<method name>, used by CustomMethod entries
// */



