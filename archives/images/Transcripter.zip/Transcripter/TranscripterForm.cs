using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.MediaPlayer.Interop; 

namespace Transcripter
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class TranscripterForm : System.Windows.Forms.Form
	{
        private System.Windows.Forms.MainMenu menu;
        private AxMicrosoft.MediaPlayer.Interop.AxWindowsMediaPlayer player;
        private System.Windows.Forms.Splitter splitter;
        private System.Windows.Forms.RichTextBox textBox;
        private System.Windows.Forms.MenuItem fileMenu;
        private System.Windows.Forms.MenuItem pauseMedia;
        private System.Windows.Forms.MenuItem rewindMediaMenu;
        private System.Windows.Forms.MenuItem openMediaMenu;
        private System.Windows.Forms.MenuItem saveMenu;
        private System.Windows.Forms.MenuItem printTimestampMenu;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public TranscripterForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(TranscripterForm));
            this.menu = new System.Windows.Forms.MainMenu();
            this.fileMenu = new System.Windows.Forms.MenuItem();
            this.openMediaMenu = new System.Windows.Forms.MenuItem();
            this.pauseMedia = new System.Windows.Forms.MenuItem();
            this.rewindMediaMenu = new System.Windows.Forms.MenuItem();
            this.printTimestampMenu = new System.Windows.Forms.MenuItem();
            this.saveMenu = new System.Windows.Forms.MenuItem();
            this.player = new AxMicrosoft.MediaPlayer.Interop.AxWindowsMediaPlayer();
            this.splitter = new System.Windows.Forms.Splitter();
            this.textBox = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.player)).BeginInit();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.fileMenu});
            // 
            // fileMenu
            // 
            this.fileMenu.Index = 0;
            this.fileMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                     this.openMediaMenu,
                                                                                     this.pauseMedia,
                                                                                     this.rewindMediaMenu,
                                                                                     this.printTimestampMenu,
                                                                                     this.saveMenu});
            this.fileMenu.Text = "File";
            // 
            // openMediaMenu
            // 
            this.openMediaMenu.Index = 0;
            this.openMediaMenu.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
            this.openMediaMenu.Text = "Open media";
            this.openMediaMenu.Click += new System.EventHandler(this.openMedia_Click);
            // 
            // pauseMedia
            // 
            this.pauseMedia.Index = 1;
            this.pauseMedia.Shortcut = System.Windows.Forms.Shortcut.CtrlP;
            this.pauseMedia.Text = "Pause media";
            this.pauseMedia.Click += new System.EventHandler(this.togglePause_Click);
            // 
            // rewindMediaMenu
            // 
            this.rewindMediaMenu.Index = 2;
            this.rewindMediaMenu.Shortcut = System.Windows.Forms.Shortcut.CtrlR;
            this.rewindMediaMenu.Text = "Rewind media 5sec";
            this.rewindMediaMenu.Click += new System.EventHandler(this.rewind_Click);
            // 
            // printTimestampMenu
            // 
            this.printTimestampMenu.Index = 3;
            this.printTimestampMenu.Shortcut = System.Windows.Forms.Shortcut.CtrlT;
            this.printTimestampMenu.Text = "Insert timestamp";
            this.printTimestampMenu.Click += new System.EventHandler(this.printTimestamp_Click);
            // 
            // saveMenu
            // 
            this.saveMenu.Index = 4;
            this.saveMenu.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
            this.saveMenu.Text = "Save transcript";
            this.saveMenu.Click += new System.EventHandler(this.saveTranscript);
            // 
            // player
            // 
            this.player.Dock = System.Windows.Forms.DockStyle.Top;
            this.player.Enabled = true;
            this.player.Location = new System.Drawing.Point(0, 0);
            this.player.Name = "player";
            this.player.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("player.OcxState")));
            this.player.Size = new System.Drawing.Size(296, 192);
            this.player.TabIndex = 0;
            // 
            // splitter
            // 
            this.splitter.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter.Location = new System.Drawing.Point(0, 192);
            this.splitter.Name = "splitter";
            this.splitter.Size = new System.Drawing.Size(296, 3);
            this.splitter.TabIndex = 1;
            this.splitter.TabStop = false;
            // 
            // textBox
            // 
            this.textBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox.Location = new System.Drawing.Point(0, 195);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(296, 182);
            this.textBox.TabIndex = 2;
            this.textBox.Text = "";
            // 
            // TranscripterForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(296, 377);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.splitter);
            this.Controls.Add(this.player);
            this.Menu = this.menu;
            this.Name = "TranscripterForm";
            this.Text = "Transcripter";
            ((System.ComponentModel.ISupportInitialize)(this.player)).EndInit();
            this.ResumeLayout(false);

        }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new TranscripterForm());
		}

        private void openMedia_Click(object sender, System.EventArgs e)
        {
            // open media file
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Media Files|*.mpg;*.avi;*.wma;*.mov;*.wav;*.mp2;*.mp3;*.wmv|All Files|*.*";

            if (DialogResult.OK == openFileDialog.ShowDialog())
            {
                player.URL = openFileDialog.FileName;
            }
        }

        private void togglePause_Click(object sender, System.EventArgs e)
        {
            TogglePause();
        }

        private void rewind_Click(object sender, System.EventArgs e)
        {
            Rewind5();
        }

        protected override bool ProcessDialogKey(Keys keyData) 
        {   
            switch (keyData) 
            {
                case Keys.Control | Keys.Space:
                    TogglePause();
                    return true;
                case Keys.Control | Keys.R:
                    Rewind5();
                    return true;
                case Keys.Control | Keys.T:
                    PrintTimestamp();
                    return true;
            }
            return base.ProcessDialogKey(keyData);
        }
 

        private void TogglePause() 
        {
            if(player.playState == WMPPlayState.wmppsPlaying) 
            {
                player.Ctlcontrols.pause();
            } 
            else 
            {
                player.Ctlcontrols.play();
            }
        }

        private void Rewind5() 
        {
            double pos = player.Ctlcontrols.currentPosition;
            player.Ctlcontrols.currentPosition = pos - 5;

            if(player.playState != WMPPlayState.wmppsPlaying) 
            {
                player.Ctlcontrols.play();
            }
        }

        private void PrintTimestamp() 
        {
            char prevChar;
            bool insertNewline = true;
            try 
            {
                int start = textBox.SelectionStart;
                prevChar = textBox.Text[start - 1];
                // todo: depending on the last characters, insert newline characters or not
                if (prevChar == 10) 
                {
                    insertNewline = false;
                }
            } 
            catch (System.IndexOutOfRangeException) { }

            textBox.SelectedText = (insertNewline ? "\r" : "") + player.Ctlcontrols.currentPositionString + "\r";
        }

        private void saveTranscript(object sender, System.EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();

            saveFileDialog.Filter = "Text Files|*.txt|All Files|*.*";

            if (DialogResult.OK == saveFileDialog.ShowDialog())
            {
                textBox.SaveFile(saveFileDialog.FileName, RichTextBoxStreamType.PlainText);
            }
        }

        private void printTimestamp_Click(object sender, System.EventArgs e)
        {
            PrintTimestamp();
        }
	}
}
