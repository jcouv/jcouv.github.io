using System;
using iTextSharp.text;
using iTextSharp.text.xml;
using iTextSharp.text.pdf;
using System.Collections;
using System.util;
using System.Xml;

namespace Manga2PDF
{
    public class CustomTextHandler : iTextmyHandler 
    {
        public CustomTextHandler(IDocListener document, Hashmap myTags) : base(document, myTags) 
        {
        }

        // copy of ParserBase.Parse(string), with a different signature
        public void ParseCustom(XmlTextReader reader) 
        {
            try 
            {
                while (reader.Read()) 
                {
                    switch (reader.NodeType) 
                    {
                        case XmlNodeType.Element:
                            string namespaceURI = reader.NamespaceURI;
                            string name = reader.Name;
                            bool isEmpty = reader.IsEmptyElement;
                            Hashtable attributes = new Hashtable();
                            if (reader.HasAttributes) 
                            {
                                for (int i = 0; i < reader.AttributeCount; i++) 
                                {
                                    reader.MoveToAttribute(i);
                                    attributes.Add(reader.Name,reader.Value);
                                }
                            }
                            this.startElement(namespaceURI, name, name, attributes);
                            if (isEmpty) 
                            {
                                endElement(namespaceURI,
                                    name, name);
                            }
                            break;
                        case XmlNodeType.EndElement:
                            endElement(reader.NamespaceURI,
                                reader.Name, reader.Name);
                            break;
                        case XmlNodeType.Text:
                            characters(reader.Value, 0, reader.Value.Length);
                            break;
                            // There are many other types of nodes, but
                            // we are not interested in them
                    }
                }
            } 
            catch (XmlException e) 
            {
                Console.WriteLine(e.Message);
            } 
            finally 
            {
                if (reader != null) 
                {
                    reader.Close();
                }
            }
        }

    }
}
