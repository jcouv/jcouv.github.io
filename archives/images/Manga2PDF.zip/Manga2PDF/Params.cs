using System;
using System.Text;
using System.Text.RegularExpressions; 

namespace Manga2PDF
{

    public class Params
    {
        public string strDir;
        public string strPattern = "\\.(jpg|gif|png)";
        public string strOutput = "output.pdf";
        public bool bRecurse = false;
        private Regex regPattern = null;
        public string strXml;
        public bool bSingleFile = false;

        public Params(string[] args)
        {   
            for (int i = 0; i < args.Length; i++) 
            {
                switch (args[i]) 
                {
                    case "-d":
                    case "-f":
                        if (i+1 < args.Length) 
                        {
                            i++;
                            strDir = args[i];
                        } 
                        else 
                        {
                            throw new Exception("bad parameters");    
                        }
                        break;
                    case "-x":
                    case "-xml":
                        if (i+1 < args.Length) 
                        {
                            i++;
                            strXml = args[i];
                        } 
                        else 
                        {
                            throw new Exception("bad parameters");    
                        }
                        break;
                    case "-p":
                    case "-pattern":
                        if (i+1 < args.Length) 
                        {
                            i++;
                            strPattern = args[i];
                        } 
                        else 
                        {
                            throw new Exception("bad parameters");    
                        }
                        break;
                    case "-o":
                    case "-output":
                        if (i+1 < args.Length) 
                        {
                            i++;
                            strOutput = args[i];
                        } 
                        else 
                        {
                            throw new Exception("bad parameters");    
                        }
                        break;
                    case "-r":
                    case "-recursive":
                        bRecurse = true;
                        break;
                    case "-s":
                    case "-singlefile":
                        bSingleFile = true;
                        break;
                    default:
                        throw new Exception("bad parameters");    
                }

                // validate what params are valid

            }
        }

        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.AppendFormat("dir: {0}\npattern: {1}\noutput: {2}\nrecurse: {3}", strDir, strPattern, strOutput, bRecurse);
            return builder.ToString();
        }

        public Regex Pattern 
        {
            get 
            {
                if (regPattern == null) 
                {
                    regPattern = new Regex(strPattern, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                }
                return regPattern;
            }
        }

    }
}
