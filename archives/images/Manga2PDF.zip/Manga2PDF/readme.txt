Usage:

One directory
Manga2PDF -d c:\manga\chapter01 -o chapter01.pdf

Recursive
Manga2PDF -d c:\manga -r

Recursive and single file output
Manga2PDF -d c:\manga -r -s

PDF from XML file
Manga2PDF -x c:\test.xml -o test.pdf

