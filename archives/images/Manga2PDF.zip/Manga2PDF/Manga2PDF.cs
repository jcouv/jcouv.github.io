using System;
using System.IO;
using System.Xml;
using System.Collections;
using System.util;
using System.Text;
using System.Drawing; 
using System.Text.RegularExpressions; 

using iTextSharp.text;
using iTextSharp.text.xml;
using iTextSharp.text.pdf;


// http://itextsharp.sourceforge.net/
// http://aspalliance.com/articleViewer.aspx?aId=71

namespace Manga2PDF
{
    public class Manga2PDF 
    {
        const string xmlbegin = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n"+
                    "<!DOCTYPE ITEXT SYSTEM \"http://www.lowagie.com/iText/itext.dtd\">\n"+
                    "<itext title=\"{0}\" subject=\"{1}\">\n";
        const string xmlend = "</itext>\n";
        const string xmlrepeat = "<{0} url=\"file:///{1}\" /><newpage/>\n";

        const string xmlchapterbegin = "<chapter><title>{0}</title>";
        const string xmlchapterend = "</chapter>";

        const string IMG = "IMG";
        const string IMG90 = "IMG90";

        [STAThread]
        static void Main(string[] args)
        {
            Params options = new Params(args);
            Console.WriteLine(options);

            if (options.strXml == null || options.strXml.Length == 0) 
            {
                if (options.bRecurse) 
                {
                    Dir2PDFRecursive(options.strDir, options.Pattern, options.bSingleFile, options.strOutput);
                } 
                else 
                {
                    Dir2PDF(options.strDir, options.Pattern, options.strOutput);

                    // open the generated PDF
                    //System.Diagnostics.Process.Start(options.strOutput);
                }
            } 
            else 
            {
                Stream outputStream = new FileStream(options.strOutput, FileMode.Create);
                Hashmap myTags = new TagMap("tagmap.xml");
                XMLFile2PDF(options.strXml, myTags, outputStream);
                System.Diagnostics.Process.Start(options.strOutput);
            }
        }

        public static void XMLFile2PDF(string strXMLFile, Hashmap myTags, Stream outputStream) 
        {
            XmlTextReader xmlreader = new XmlTextReader(strXMLFile);
            XML2PDF(xmlreader, myTags, outputStream);
        }

        public static void Dir2PDF(string strDir, Regex pattern, string strOutput) 
        {
            XmlTextReader xmlreader = Dir2XML(strDir, pattern);
            Hashmap myTags = new TagMap("tagmap.xml");

            Stream outputStream = new FileStream(strOutput, FileMode.Create);

            // read the xml and output to the file
            XML2PDF(xmlreader, myTags, outputStream);
        }

        public static void Dir2PDFRecursive(string strDir, Regex pattern, bool bSingleFile, string strOutput) 
        {
            XmlTextReader xmlreader;
            Hashmap myTags = new TagMap("tagmap.xml");
            Stream outputStream;

            if (bSingleFile) 
            {
                xmlreader = Dir2XMLRecursiveSingle(strDir, pattern);
                outputStream = new FileStream(strOutput, FileMode.Create);
                XML2PDF(xmlreader, myTags, outputStream);
            }
            else 
            {
                DirectoryInfo topDir = new DirectoryInfo(strDir);
                DirectoryInfo[] subDirs = topDir.GetDirectories();
                foreach (DirectoryInfo subDir in subDirs) 
                {
                    Console.WriteLine("Found directory: {0}", subDir.FullName);
                    xmlreader = Dir2XML(subDir.FullName, pattern);
                    outputStream = new FileStream(subDir.Name + ".pdf", FileMode.Create);
                    XML2PDF(xmlreader, myTags, outputStream);
                }
            }
        }

        public static XmlTextReader Dir2XML(string dirPath, Regex pattern) 
        {
            DirectoryInfo di = new DirectoryInfo(dirPath);
            FileInfo[] rgFiles = di.GetFiles();
            StringBuilder builder = new StringBuilder();
            builder.AppendFormat(xmlbegin, "title", "subject");

            foreach(FileInfo fi in rgFiles)
            {
                if (pattern.IsMatch(fi.Name)) 
                {
                    System.Drawing.Bitmap img = new System.Drawing.Bitmap(fi.FullName);
                    string tag = (img.Width < img.Height) ? IMG : IMG90;

                    builder.AppendFormat(xmlrepeat, tag, fi.FullName);
                    Console.WriteLine("Found image {0}", fi.Name);
                } 
                else 
                {
                    Console.WriteLine("Discarded file {0}", fi.Name);
                }
            }

            builder.Append(xmlend);

            string strXML = builder.ToString();
            StringReader strReader = new StringReader(strXML);
            
            return new XmlTextReader(strReader);
        }

        public static XmlTextReader Dir2XMLRecursiveSingle(string topDirPath, Regex pattern) 
        {
            DirectoryInfo topDir = new DirectoryInfo(topDirPath);
            DirectoryInfo[] subDirs = topDir.GetDirectories();

            StringBuilder builder = new StringBuilder();
            builder.AppendFormat(xmlbegin, "title", "subject");

            foreach (DirectoryInfo subDir in subDirs) 
            {
                Console.WriteLine("Found directory: {0}", subDir.FullName);
                builder.AppendFormat(xmlchapterbegin, subDir.Name);

                FileInfo[] subFiles = subDir.GetFiles();

                foreach(FileInfo subFile in subFiles)
                {
                    if (pattern.IsMatch(subFile.Name)) 
                    {
                        System.Drawing.Bitmap img = new System.Drawing.Bitmap(subFile.FullName);
                        string tag = (img.Width < img.Height) ? IMG : IMG90;

                        builder.AppendFormat(xmlrepeat, tag, subFile.FullName);
                        Console.WriteLine("Found image {0}", subFile.Name);
                    } 
                    else 
                    {
                        Console.WriteLine("Discarded file {0}", subFile.Name);
                    }
                }
                builder.Append(xmlchapterend);
            }

            builder.Append(xmlend);

            string strXML = builder.ToString();
            StringReader strReader = new StringReader(strXML);
            
            return new XmlTextReader(strReader);
        }

        public static void XML2PDF(XmlTextReader xmlreader, Hashmap myTags, Stream outputStream) 
        {
            // creation of a document-object
            Document document = new Document(PageSize.LEGAL, 20, 20, 20, 20);
            
            try 
            {
                // create a writer that listens to the document
                // and directs a XML-stream to a file
                PdfWriter.getInstance(document, outputStream);
            
                // create a parser
                CustomTextHandler h = new CustomTextHandler(document, myTags);
            
                // parse the document
                h.ParseCustom(xmlreader);
            }
            catch (Exception e) 
            {
                Console.Error.WriteLine(e.StackTrace);
                Console.Error.WriteLine(e.Message);
            }
        }
    }

}
