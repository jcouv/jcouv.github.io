using System;
using System.Web;
using System.Threading;

using TypeKeySecurity;

namespace TypeKeyAuthenticationDemo
{
	public class Default : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label loggedin;
		protected System.Web.UI.WebControls.Label email;
        protected System.Web.UI.WebControls.Label name;
        protected System.Web.UI.WebControls.Label nick;
        protected System.Web.UI.WebControls.Label fresh;
        protected System.Web.UI.WebControls.HyperLink scarab;
        protected System.Web.UI.WebControls.Label namehash;
        protected System.Web.UI.WebControls.Label foaf;
        protected System.Web.UI.WebControls.Label error;

		private void Page_Load(object sender, System.EventArgs e)
		{
        
                // todo set no cache headers

                //HttpApplication app = (HttpApplication)sender;
                this.loggedin.Text = (Context.User.Identity.IsAuthenticated ? "true" : "false");

                TypeKeyIdentity id = (TypeKeyIdentity)Context.User.Identity;
 
                email.Text = id.Email;
                name.Text = id.Name;
                namehash.Text = id.NameHash.ToString();
                nick.Text = id.Nick;

                if (id.IsAuthenticated) 
                {
                    scarab.Text = "log out!";
                    scarab.NavigateUrl = id.LogoutUrl();
                } 
                else 
                {
                    scarab.NavigateUrl = id.LoginUrl(false);
                    scarab.Text = "log in!";
                }

                fresh.Text = (id.IsAuthFresh(60) ? "true" : "false");
                foaf.Text = id.FOAFUrl; 
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
