// TypeKeySecurity plug-in authentication module for ASP.Net
// Copyright (C) 2004 Julien Couvreur. 
// Details in license.txt file (GPLv2).
using System;
using System.Collections.Specialized;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Web;

namespace TypeKeySecurity
{
    // todo add a webcontrol for the "scarab"
    // todo add a public event like PassportAuthenticationModule.Authenticate
    // todo add helper method to differentiate users with email and users with SHA-1 email
    // todo add a way to fetch the FOAF file for a given user

    /// <summary>Module that takes care of checking incoming requests for
    /// TypeKey identity assertions, and create a TypeKeyIdentity object
    /// accordingly.</summary>
    /// <remarks>
    /// The TypeKey protocol is documented at <a href="http://www.movabletype.org/docs/tk-apps.html">http://www.movabletype.org/docs/tk-apps.html</a>.
    /// 
    /// This module enables you to use the TypeKey service with minimal code. For your ASP.Net site to 
    /// use this module, it needs to be listed in the httpModules in your web.config, as shown below.
    /// 
    /// <example><code>
    /// &lt;?xml version="1.0" encoding="utf-8" ?>
    /// &lt;configuration>
    ///     &lt;system.web>
    ///         &lt;authentication mode="None" />
    ///         &lt;httpModules>
    ///             &lt;add name="TypeKeyAuthenticationModule" 
    ///             type="TypeKeySecurity.TypeKeyAuthenticationModule, TypeKeySecurity" />
    ///         &lt;/httpModules>
    ///     &lt;/system.web>
    ///     &lt;appSettings>
    ///         &lt;add key="TypeKeySecurity.Token.Value" value="0123456789ABCDEF0123" />
    ///     &lt;/appSettings>
    /// &lt;/configuration></code>
    /// </example>
    /// </remarks>
    public sealed class TypeKeyAuthenticationModule : IHttpModule
    {
        HttpApplication app = null;

        /// <summary>Initializes the module derived from IHttpModule when called by the HttpRuntime.</summary>    
        public void Init(HttpApplication httpapp)
        {
            this.app = httpapp;
            app.AuthenticateRequest += new EventHandler(this.OnAuthenticate);
        }

        /// <summary>Handler for the HttpApplication AuthenticateRequest event.</summary>
        private void OnAuthenticate(object sender, EventArgs e)
        {
            app = (HttpApplication)sender;
            TypeKeyIdentity userIdentity = null;

            // if logout=1, then clear the auth cookies
            if (CheckLogout()) 
            {
                // just logged out, let's ignore the current auth cookie
                userIdentity = new TypeKeyIdentity(app);
            } 
            else 
            {
                // try authentication by querystring
                userIdentity = TypeKeyIdentity.AuthenticateFromQueryString(app, app.Request.QueryString);
                
                if (userIdentity != null) 
                {
                    HttpResponse res = app.Response;
                    HttpCookie cookie = userIdentity.MakeCookie(app);                
                    res.Cookies.Add(cookie);
                } 
                else 
                {
                    // try authentication by cookie
                    userIdentity = TypeKeyIdentity.AuthenticateFromCookie(app);

                    // no authentication occured
                    if (userIdentity == null) 
                    {
                        userIdentity = new TypeKeyIdentity(app);
                    }
                } 
            }

            // set principal
            string[] arrRoles = new string[0]; // no roles...
            GenericPrincipal principal = new GenericPrincipal(userIdentity, arrRoles);
            app.Context.User = principal;
            // Thread.CurrentPrincipal = principal;

            if (userIdentity.FromTypeKeyServer) 
            {
                app.Response.Redirect(userIdentity.GetCleanUrl(), true);
            }
        }

        /// <summary>Check for logout parameter on the querystring. If present, bounce on TypeKey for logout.</summary>
        private bool CheckLogout() 
        {
            if (app.Request.QueryString[TypeKeyIdentity.QS_LOGOUT] != null) 
            {
                // todo is there a way to let the coder hook up into the signout code to clear more cookies?
                // clean url and pass it in LogoutUser()

                app.Response.Cookies.Add(TypeKeyIdentity.MakeLogoutCookie());
                return true;
            }

            return false;
        }

        /// <summary>Disposes the module.</summary>
        public void Dispose() 
        {

        }
    }
}
