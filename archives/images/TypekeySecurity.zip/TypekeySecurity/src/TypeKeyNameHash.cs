// TypeKeySecurity plug-in authentication module for ASP.Net
// Copyright (C) 2004 Julien Couvreur. 
// Details in license.txt file (GPLv2).
using System;
using System.Text;

namespace TypeKeySecurity
{
    /// <summary>Numeric representation (128 bits) of the unique identifier (TypeKey name) of a user.
    ///     Derived from the name using a MD5 hash.</summary>
    /// <remarks>Returned by <b>TypeKeyIdentity.NameHash</b>. <b>TypeKeyIdentity.Name</b> is the original 
    ///     unique identifier, in a string format.</remarks>
    public class TypeKeyNameHash 
    {
        private Int64 idHigh;
        private Int64 idLow;

        /// <summary>Gets the high 64 bits of the name hash.</summary>
        /// <value>The top half of the hash, as an Int64.</value>
        public Int64 IdHigh 
        {
            get { return idHigh; }
        }

        /// <summary>Gets the low 64 bits of the name hash.</summary>
        /// <value>The bottom half of the hash, as an Int64.</value>
        public Int64 IdLow
        {
            get { return idLow; }
        }

        internal TypeKeyNameHash() 
        {
        }

        /// <summary>Construct from a MD5 hash.</summary>
        /// <param name="hash">128 bits from the MD5 hash, stored in a byte[16] array</param>
        /// <exception cref="Exception">Throws an exception if the size of the input array isn't 16.</exception>
        internal TypeKeyNameHash(byte[] hash) 
        {
            if (hash.Length != 16) 
            {
                throw new Exception("Hash size should be 16 bytes");
            }

            Int64 power = 1;
            for (int i = 7; i >= 0; i--) 
            {
                idHigh += (hash[i] * power);
                power *= 256;
            }
            power = 1;
            for (int i = 15; i >= 8; i--) 
            {
                idLow += (hash[i] * power);
                power *= 256;
            }

            //BigInteger i = new BigInteger("E5F1BC62780D77082E1DBFCC1B9AD97B", 16);
            //string test = new TypeKeyNameHash(i.getBytes()).ToString();
        }

        /// <summary>Convert the 128 number to a hexadecimal string.</summary>
        /// <returns>Returns a string formatted as "0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF".</returns>
        public override string ToString() 
        {
            StringBuilder str = new StringBuilder();
            str.AppendFormat("0x{0:X16}{1:X16}", idHigh, idLow);
            return str.ToString();
        }

        // todo add at GUID formatted output
    }

}
