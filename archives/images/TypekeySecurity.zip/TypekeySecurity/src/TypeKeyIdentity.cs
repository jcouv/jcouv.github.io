// TypeKeySecurity plug-in authentication module for ASP.Net
// Copyright (C) 2004 Julien Couvreur. 
// Details in license.txt file (GPLv2).
using System;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Web;
using System.Web.Caching;

namespace TypeKeySecurity
{
    /// <summary>Represents the Identity of a User.</summary>
    /// <example><code>
    /// using TypeKeySecurity;
    /// 
    /// TypeKeyIdentity id = (TypeKeyIdentity)Context.User.Identity;
    /// 
    /// // was the user authenticated within 600 seconds (10 minutes)?
    /// if (id.IsAuthFresh(600)) {
    ///     // access id.Name, id.NameHash, id.Email and id.Nick
    ///     // log the user out with LogoutUser and LogoutUrl
    /// } else {
    ///     id.LoginUser(false); // force the user to log in
    ///     // or use LoginUrl
    /// }</code></example>
    /// <remarks>After you install the TypeKeyAuthenticationModule, a TypeKeyIdentity object is made available 
    ///     to you in every incoming request.<br/>
    /// 
    ///     For more information on TypeKey authentication, see 
    ///     <a href="http://www.movabletype.org/docs/tk-apps.html">http://www.movabletype.org/docs/tk-apps.html</a>.</remarks>
    [Serializable]
    public class TypeKeyIdentity : IIdentity
    {
        # region private variables

        private HttpApplication app; // holds the current request/response/server objects
        private bool loggedin = false; // whether TypeKey authenticated you (signature verified)
        private string email;
        private string name; // unique identifier
        private TypeKeyNameHash hash; // numeric unique identifier (MD5 hash of the name)
        private string nick;
        private int ts; // timestamp of the TypeKey authentication
        private string sig; // TypeKey DSA signature
        private bool fromTypeKeyServer = false; // did the user just come back from the TypeKey servers?

        #endregion

        #region constants

        /// <summary>The site token has to be configured via the AppSettings in the 
        ///     web.config file using this key.</summary>
        /// <remarks>This token is provided when you register your site with 
        ///     the TypeKey service. You can't use TypeKey if you don't configure 
        ///     this</remarks>
        /// <example><code>
        /// &lt;appSettings>
        ///     &lt;add key="TypeKeySecurity.Token.Value" value="0123456789ABCDEF0123" />
        /// &lt;/appSettings></code></example>
        public const string SITE_TOKEN_KEY = "TypeKeySecurity.Token.Value";

        
        /// <summary>Default name for the authentication cookie.</summary>
        /// <remarks>Default url is "tkcookie"</remarks>
        public const string COOKIE_NAME_DEFAULT = "tkcookie"; // default cookie name

        /// <summary>The cookie name may be configured in the web.config file 
        ///     using this key.</summary>
        /// <remarks>Chances are the default cookie name is fine for most uses.</remarks>
        public const string COOKIE_NAME_KEY = "TypeKeySecurity.Cookie.Name";


        /// <summary>Default expiration time for the authentication cookie.</summary>
        /// <remarks>Expiration time in seconds. Zero is used to signify a "session" cookie. Default is "0".</remarks>
        public const int COOKIE_EXPIRATION_DEFAULT = 0;

        /// <summary>The cookie expiration may be configured in the web.config file 
        ///     using this key.</summary>
        /// <remarks>Zero means session cookie.</remarks>
        public const string COOKIE_EXPIRATION_KEY = "TypeKeySecurity.Cookie.Expiration";


        /// <summary>Default url for the TypeKey login service.</summary>
        /// <remarks>Default url is "https://www.typekey.com/t/typekey/login"</remarks>
        public const string LOGIN_LOCATION_DEFAULT = "https://www.typekey.com/t/typekey/login";

        /// <summary>The url of the TypeKey login service can be configured via the 
        ///     AppSettings in the web.config file using this key.</summary>
        /// <remarks>If you don't use the TypeKey hosted authentication, use the 
        ///     web.config to specify the login url.</remarks>
        public const string LOGIN_LOCATION_KEY = "TypeKeySecurity.Login.Location";


        /// <summary>Default url for the TypeKey logout service.</summary>
        /// <remarks>Default url is "https://www.typekey.com/t/typekey/logout"</remarks>
        public const string LOGOUT_LOCATION_DEFAULT = "https://www.typekey.com/t/typekey/logout";

        /// <summary>The url for the TypeKey logout service can be configured via 
        ///     the AppSettings in the web.config file using this key.</summary>
        /// <remarks>If you don't use the TypeKey hosted authentication, use the 
        ///     web.config to specify the logout url.</remarks>
        public const string LOGOUT_LOCATION_KEY = "TypeKeySecurity.Logout.Location";


        /// <summary>Default url for the TypeKey public DSA key.</summary>
        /// <remarks>Default url is "http://www.typekey.com/extras/regkeys.txt".</remarks>
        public const string PUBKEY_LOCATION_DEFAULT = "http://www.typekey.com/extras/regkeys.txt"; 

        /// <summary>The location for fetching the public DSA key for the TypeKey 
        ///     service can be configured via the AppSettings in the web.config file 
        ///     using this key.</summary>
        /// <remarks>If you don't use the TypeKey hosted authentication, use the 
        ///     web.config to specify the public key url.</remarks>
        public const string PUBKEY_LOCATION_KEY = "TypeKeySecurity.PubKey.Location";


        /// <summary>Default url for the TypeKey FOAF files.</summary>
        /// <remarks>Default url is "http://profile.typekey.com/{0}/foaf.rdf". {0} replaces the user name.</remarks>
        public const string FOAF_LOCATION_DEFAULT = "http://profile.typekey.com/{0}/foaf.rdf"; 

        /// <summary></summary>
        /// <remarks></remarks>
        public const string FOAF_LOCATION_KEY = "TypeKeySecurity.FOAF.Location";

        
        internal const string QS_EMAIL = "email";
        internal const string QS_NAME = "name";
        internal const string QS_NICK = "nick";
        internal const string QS_TS = "ts"; // timestamp
        internal const string QS_SIG = "sig"; // DSA signature
        
        internal const string QS_LOGOUT = "logout";



        /// <summary>Timeout for caching the TypeKey public key.</summary>
        /// <value>Timeout delay in seconds.</value>
        private const int PUBKEY_CACHE_TIMEOUT = 60 * 60 * 24; // one day in seconds

        /// <summary>Name of the file (in the temp directory) used to cache the TypeKey public DSA key.</summary>
        private const string PUBKEY_TEMPFILE = @"\TypeKeyPubKey.txt";

        private const string PUBKEY_CACHE_NAME = "TypeKeyPubKey"; // where we cache the public key in the application cache.

        /// <summary>Minimun frequency between two authentications for a given user.</summary>
        /// <remarks>Helps avoiding loops where an already authenticated user is sent over and 
        /// over again to the TypeKey service to get authenticated.</remarks>
        /// <remarks>Miniumum time in seconds between authentications.</remarks>
        private const int MIN_LOGIN_FREQ = 10;

        #endregion

        #region constructors

        /// <summary>Construct an empty/un-authenticated TypeKey identity</summary>
        /// <param name="_app">HttpApplication for the current request.</param>
        internal TypeKeyIdentity(HttpApplication _app)
        {
            app = _app;
        }

        /// <summary>Construct a TypeKey identity.</summary>
        /// <param name="_app">HttpApplication for the current request.</param>
        /// <param name="_email">Authenticated user's email address.</param>
        /// <param name="_name">User's unique identifier.</param>
        /// <param name="_nick">User's display nick.</param>
        /// <param name="_ts">Timestamp of the authentication.</param>
        /// <param name="_sig">DSA signature for the authentication assertion.</param>
        /// <seealso cref="CheckSignature"/>
        internal TypeKeyIdentity(HttpApplication _app, string _email, string _name, string _nick, int _ts, string _sig)
        {
            app = _app;
            email = _email;
            name = _name;
            nick = _nick;
            ts = _ts;
            sig = _sig;

            // construct the hash of "name"
            UTF8Encoding utf8 = new UTF8Encoding();
            byte[] data = utf8.GetBytes(name);
            MD5 md5 = new MD5CryptoServiceProvider();
            byte[] result = md5.ComputeHash(data);
            hash = new TypeKeyNameHash(result);

            // validate the DSA signature
            CheckSignature();
        }

        #endregion

        #region factories

        /// <summary>Build a TypeKeyIdentity from a querystring</summary>
        /// <returns>Returns null if no authentication occured</returns>
        internal static TypeKeyIdentity AuthenticateFromQueryString(HttpApplication _app, NameValueCollection qs) 
        {
            TypeKeyIdentity id = AuthenticateFromCollection(_app, qs);
            if (id != null && id.IsAuthenticated) 
            {
                // the authentication occured via the querystring so the user
                //  just came back from the TypeKey servers
                id.fromTypeKeyServer = true;
            }
            return id;
        }

        /// <summary>
        /// Build a TypeKeyIdentity from a name value collection
        /// </summary>
        /// <returns>Returns null if no authentication occured</returns>
        private static TypeKeyIdentity AuthenticateFromCollection(HttpApplication _app, NameValueCollection qs) 
        {   
            string email;
            string name;
            string nick;
            string ts;
            string sig;

            // Load all elements from the QS
            email = qs[QS_EMAIL];
            name = qs[QS_NAME];
            nick = qs[QS_NICK];
            ts = qs[QS_TS];
            sig = qs[QS_SIG];

            // verify required parameters
            if (email == null || name == null || nick == null || ts == null || sig == null) 
            {
                return null;
            }

            // If we find a comma, that means that parameter was specified multiple times on the querystring
            if (email.IndexOf(',') != -1 ||
                name.IndexOf(',') != -1 ||
                nick.IndexOf(',') != -1 ||
                ts.IndexOf(',') != -1 ||
                sig.IndexOf(',') != -1) 
            {
                return null;
            }

            TypeKeyIdentity id = new TypeKeyIdentity(_app, email, name, nick, Int32.Parse(ts), sig);            
            if (id.IsAuthenticated) 
            {
                return id;
            } 
            else 
            {
                return null;
            }
        }

        /// <summary>Build a TypeKeyIdentity from a querystring formatted email.</summary>
        /// <remarks>Cookie format: "name=[name]&amp;nick=[nick]&amp;email=[email]&amp;sig=[signature]"</remarks>
        /// <param name="_app">HttpApplication for the current request</param>
        /// <returns>Returns null if no authentication assertion was found in the cookies. Returns the 
        /// TypeKeyIdentity when one is found and verified.</returns>
        internal static TypeKeyIdentity AuthenticateFromCookie(HttpApplication _app) 
        {
            // is cookie set?
            HttpCookieCollection cookies = _app.Request.Cookies;
            if(cookies.Count <= 0) 
            {
                return null;
            }
            HttpCookie cookie = cookies[GetCookieName().ToUpper()];
            if (cookie == null) 
            {
                return null;
            }

            // parse cookie
            NameValueCollection collection = ParseQuerystringFormat(_app, cookie.Value);

            // authenticate
            return AuthenticateFromCollection(_app, collection);
        }

        #endregion

        # region properties

        /// <summary>Gets the type of authentication used to identify the user.</summary>
        /// <value>Returns the string "Custom".</value>
        public string AuthenticationType 
        {
            get { return "Custom"; }
        }
        
        /// <summary>
        /// Whether the user was authenticated.
        /// Caller should also use <c>IsAuthFresh</c> to verify freshness of the authentication.
        /// </summary>
        /// <value>If the user has creds, returns true.</value>
        /// <remarks>This method doesn't consider whether the creds are fresh or not.</remarks>
        /// <seealso cref="IsAuthFresh"/>
        public bool IsAuthenticated 
        {
            get { return loggedin; }
        }

        /// <summary>Login name of an authenticated user. Unique identifier.</summary>
        /// <value>String representing the user's login name.</value>
        /// <remarks>Returns an empty string if the user isn't authenticated.</remarks>
        public string Name
        { 
            get { return (loggedin ? name : String.Empty); }
        }

        /// <summary>MD5 hash of <c>Name</c>. Provides a numerical unique identifier (an 128 bit integer).</summary>
        /// <value>A TypeKeyNameHash object derived from the <c>Name</c>.</value>
        /// <remarks>Returns hash zero if the user isn't authenticated.</remarks>
        public TypeKeyNameHash NameHash
        {
           get { return (loggedin ? hash : new TypeKeyNameHash()); }
        }

        /// <summary>Email address of the authenticated user.</summary>
        /// <remarks>Only the SHA-1 hash of the email is available by default, unless 
        ///     <c>needEmail</c> was set to true during the authentication request.</remarks>
        /// <value>Returns an empty string if the user isn't authenticated.</value>
        public string Email 
        {
            get { return (loggedin ? email : String.Empty); }
        }

        /// <summary>Display name of the authenticated user.</summary>
        /// <value>The display name of the user.</value>
        /// <remarks>Returns an empty string if the user isn't authenticated.</remarks>
        public string Nick
        {   
            get { return (loggedin ? nick : String.Empty); }
        }

        /// <summary>Timestamp of the authentication.</summary>
        /// <value>Time of the authentication in epoch.</value>
        /// <remarks>Returns zero if the user isn't authenticated.</remarks>
        public int TimeStamp
        {
            get { return (loggedin ? ts : 0); }
        }

        /// <summary>Whether the user is just coming back from the TypeKey server.</summary>
        internal bool FromTypeKeyServer
        {
            get { return fromTypeKeyServer; }
        }

        /// <summary>Url for the FOAF file for the authenticated user.</summary>
        /// <value>FOAF file's location.</value>
        /// <remarks>Returns an empty string if the user isn't authenticated.</remarks>
        public string FOAFUrl
        {
            get 
            {
                if (!IsAuthenticated)
                {
                    return String.Empty;
                }
                // load the configured setting
                string foafLocation = ConfigurationSettings.AppSettings[FOAF_LOCATION_KEY];
                if(foafLocation == null || foafLocation.Trim() == String.Empty)
                {
                    foafLocation = FOAF_LOCATION_DEFAULT;
                }
                
                // replace the username in the FOAF path
                StringBuilder foafUrl = new StringBuilder();
                foafUrl.AppendFormat(foafLocation, name);

                return foafUrl.ToString();
            }
        }

        #endregion

        #region static methods

        /// <summary>What's the name of the cookie?</summary>
        /// <returns>Returns either the configured cookie name or the default.</returns>
        private static string GetCookieName()
        {
            // load the configured setting
            string cookieName = ConfigurationSettings.AppSettings[COOKIE_NAME_KEY];
            if(cookieName != null && cookieName.Trim() != String.Empty)
            {
                return cookieName;
            } 

            // default
            return COOKIE_NAME_DEFAULT;
        }

        /// <summary>
        /// How long do we want the cookie to stick around?
        ///     (in seconds)
        /// </summary>
        /// <returns>Returns zero if the cookie should be a session cookie</returns>
        private static int GetCookieExpiration()
        {
            // load the configured setting
            string strExpiration = ConfigurationSettings.AppSettings[COOKIE_EXPIRATION_KEY];
            if(strExpiration != null && strExpiration.Trim() != String.Empty)
            {
                try 
                {
                    int iExpiration = Int32.Parse(strExpiration);
                    return iExpiration;
                } 
                catch {}
            } 
            
            return COOKIE_EXPIRATION_DEFAULT;
        }

        /// <summary>Get the site token.</summary>
        /// <exception cref="Exception">Throws an exception when the setting isn't found</exception>
        private static string GetSiteToken()
        {
            string token = ConfigurationSettings.AppSettings[SITE_TOKEN_KEY];
            if(token != null && token.Trim() != String.Empty)
            {
                return token;    
            }

            throw new Exception(SITE_TOKEN_KEY + "entry (required) not found in appSettings section of the web.config file.");
        }

        /// <summary>What is the TypeKey login url?</summary>
        private static string GetLoginUrl() 
        {
            // load the configured setting
            string loginLocation = ConfigurationSettings.AppSettings[LOGIN_LOCATION_KEY];
            if(loginLocation != null && loginLocation.Trim() != String.Empty)
            {
                return loginLocation;
            } 

            return LOGIN_LOCATION_DEFAULT;
        }

        /// <summary>What is the TypeKey logout url?</summary>
        private static string GetLogoutUrl() 
        {
            // load the configured setting
            string logoutLocation = ConfigurationSettings.AppSettings[LOGOUT_LOCATION_KEY];
            if(logoutLocation != null && logoutLocation.Trim() != String.Empty)
            {
                return logoutLocation;
            } 

            return LOGOUT_LOCATION_DEFAULT;
        }

        /// <summary>Where should we fetch the TypeKey DSA public key from?</summary>
        /// <returns>Returns either the configured location or the default.</returns>
        private static string GetPublicDsaKeyUrl() 
        {
            // load the configured setting
            string pubkeyLocation = ConfigurationSettings.AppSettings[PUBKEY_LOCATION_KEY];
            if(pubkeyLocation != null && pubkeyLocation.Trim() != String.Empty)
            {
                return pubkeyLocation;
            } 
            
            return PUBKEY_LOCATION_DEFAULT;
        }

  
        /// <summary>How long do we want to allow to cache the DSA Key? (in seconds)</summary>
        private static int GetKeyCacheTimeout()
        {
            return PUBKEY_CACHE_TIMEOUT;
        }



        /// <summary>Clear the authentication cookie.</summary>
        /// <returns>A cookie that expires the authentication cookie and blanks it out.</returns>
        /// <remarks>Only useful if you want to write your own sign-out code.</remarks>
        public static HttpCookie MakeLogoutCookie() 
        {
            HttpCookie cookie = new HttpCookie(GetCookieName());
            cookie.Expires = new DateTime(1970, 1, 1);
            return cookie;
        }

        /// <summary>Parse a querystring formatted string.</summary>
        /// <param name="input">A querystring formatted string.</param>
        /// <param name="_app">HttpApplication for the current request.</param>
        private static NameValueCollection ParseQuerystringFormat(HttpApplication _app, string input) 
        {
            NameValueCollection output = new NameValueCollection();
            char[] ampersandSplitter = {'&'};
            char[] equalSplitter = {'='};
            string[] pairs = input.Split(ampersandSplitter);

            foreach (string pair in pairs) 
            {
                string[] item = pair.Split(equalSplitter);
                if (item.Length != 2) 
                {
                    break;
                }
                if (output[item[0]] != null) 
                {
                    break;
                }
                output[item[0]] = _app.Server.UrlDecode(item[1]);
            }

            return output;
        }

        
        private static string GetTypekeyPublicDsaKeyString() 
        {
            string key;
            
            // is there a cached version?
            string path = System.Environment.GetEnvironmentVariable("temp") + PUBKEY_TEMPFILE;
            if (File.Exists(path)) 
            {
                // how fresh is it?
                DateTime lastUpdated = File.GetLastWriteTimeUtc(path);
                double secondsSinceUpdate = (DateTime.UtcNow - lastUpdated).TotalSeconds;
                if (secondsSinceUpdate < GetKeyCacheTimeout()) 
                {
                    // read the cached file
                    key = File.OpenText(path).ReadLine();
                    return key;
                }
            }

            // fetch key from TypeKey server
            WebClient client = new WebClient();
            Stream stream = client.OpenRead(GetPublicDsaKeyUrl());
            StreamReader sr = new StreamReader(stream);
            key = sr.ReadLine();
            sr.Close();

            // save the file to cache
            StreamWriter sw = new StreamWriter(path, false);
            sw.WriteLine(key);
            sw.Close();
            
            if (key.Length == 0) 
            {
                throw new Exception("TypeKey public DSA key fetch failed");
            }

            return key;
        }

        #endregion

        #region instance methods

        /// <summary>Redirect the user to the Typekey server to get authenticated,
        ///     with the return url set to the current page.</summary>
        /// <param name="needEmail">Whether you are requesting the cleartext version of the user's email.</param>
        /// <remarks>Use this for pages that require the user to be logged in.</remarks>
        public void LoginUser(bool needEmail) 
        {
            LoginUser(needEmail, app.Request.Url.ToString());
        }

        /// <summary>Redirect the user to the Typekey server to get authenticated.</summary>
        /// <param name="needEmail">Whether you are requesting the cleartext version of the user's email.</param>
        /// <param name="returnUrl">Specify the return url you need.</param>
        /// <remarks>Use this for pages that require the user to be logged in.</remarks>
        public void LoginUser(bool needEmail, string returnUrl) 
        {
            int nowEpoch = (int) (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds;

            if (nowEpoch - ts < MIN_LOGIN_FREQ) 
            {
                throw new Exception("You can't refresh a user's cred more often than " + MIN_LOGIN_FREQ + " seconds");
            }
            
            app.Response.Redirect(LoginUrl(needEmail, returnUrl), true);
        }

        /// <summary>Build a url to send the user to the Typekey server to get authenticated,
        ///     with the return url set to the current page.</summary>
        /// <param name="needEmail">Whether you are requesting the cleartext version of the user's email.</param>
        /// <returns>Returns a TypeKey url that will prompt the user for his creds or silently log him in,
        ///     when possible.</returns>
        /// <remarks>Unless you really need the user's email, use <c>needEmail=false</c>.</remarks>
        public string LoginUrl(bool needEmail) 
        {
            return LoginUrl(needEmail, app.Request.Url.ToString());
        }

        /// <summary>Build a url to send the user to the Typekey server to get authenticated.</summary>
        /// <param name="needEmail">Whether you are requesting the cleartext version of the user's email.</param>
        /// <param name="returnUrl">Specify the return url you need.</param>
        /// <returns>Returns a TypeKey url that will prompt the user for his creds or silently log him in
        ///     (when possible).</returns>
        /// <remarks>The user will be sent back the the <c>returnUrl</c> you specify.
        ///     Unless you really need the user's email, use <c>needEmail=false</c>.</remarks>
        public string LoginUrl(bool needEmail, string returnUrl) 
        {
            StringBuilder url = new StringBuilder();
            url.AppendFormat("{0}?t={1}", GetLoginUrl(), app.Server.UrlEncode(GetSiteToken()));
            if (needEmail) 
            {
                url.Append("&need_email=1");
            }
            url.AppendFormat("&_return={0}", app.Server.UrlEncode(GetCleanUrl(new Uri(returnUrl))));
            return url.ToString();
        }

        /// <summary>Clear authentication cookies and redirect to TypeKey logout url.</summary>
        /// <remarks>Returns back to the current url (with logout=1).</remarks>
        public void LogoutUser() 
        {
            LogoutUser(app.Request.Url.ToString());
        }

        /// <summary>Clear authentication cookies and redirect to TypeKey logout url.</summary>
        /// <param name="returnUrl">Where the user should be returned after getting logged out.</param>
        /// <remarks>Returns back to the <c>returnUrl</c> with logout=1.</remarks>
        public void LogoutUser(string returnUrl) 
        {
            // clear auth cookie
            app.Response.Cookies.Add(MakeLogoutCookie());
            
            // redirect to TypeKey's logout url
            app.Response.Redirect(LogoutUrl(returnUrl), true);
        }


        /// <summary>Build a url to send the user to the TypeKey server to get logged out</summary>
        /// <returns>Returns the TypeKey logout url with a return url to the current page.</returns>
        /// <remarks>After the user is logged out, he'll be sent back the current page.</remarks>
        public string LogoutUrl() 
        {
            return LogoutUrl(app.Request.Url.ToString());
        }

        /// <summary>Build a url to send the user to the TypeKey server to get logged out.</summary>
        /// <param name="returnUrl">Specify the return url you need.</param>
        /// <returns>Returns the TypeKey logout url with a return url to the <c>returnUrl</c>.</returns>
        /// <remarks>After the user is logged out, he'll be sent back the <c>returnUrl</c>.</remarks>
        public string LogoutUrl(string returnUrl)
        {
            StringBuilder url = new StringBuilder();
            StringBuilder logoutru = new StringBuilder(returnUrl);

            char separator = (returnUrl.IndexOf('?') != -1) ? '&' : '?';
            logoutru.AppendFormat("{0}{1}=1", separator, QS_LOGOUT);

            url.AppendFormat("{0}?_return={1}", GetLogoutUrl(), app.Server.UrlEncode(logoutru.ToString()));
            return url.ToString();
        }

        /// <summary>Whether the authentication occured within the timewindow.</summary>
        /// <param name="timewindow">Time window in seconds.</param>
        /// <returns>Returns true if the user was authenticated less than <c>timewindow</c> seconds ago.</returns>
        /// <remarks>The timewindow is sensitive to any time skews between your server and the TypeKey server.</remarks>
        public bool IsAuthFresh(int timewindow)
        {
            if (!loggedin) { return false; }

            int nowEpoch = (int) (DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0)).TotalSeconds;

            return (nowEpoch - ts < timewindow);
        }
        
        /// <summary>Whether the <c>Email</c> field is a SHA-1 hash or an actual email address.</summary>
        /// <remarks>If the authentication occured with <c>needEmail</c> set to true, then 
        ///     the actual email should be available.</remarks>
        /// <returns>Returns true if it's a SHA-1 hash.</returns>
        public bool IsEmailHashed()
        {
            if (email.Length == 40 || email.IndexOf('@') == -1) 
            {
                return true;
            }
            return false;
        }

        /// <summary>Returns the current authentication assertion as a cookie.</summary>
        /// <remarks>The cookie expiration can be configured.</remarks>
        /// <param name="_app">HttpApplication for the current request.</param>        
        /// <returns>Cookie formatted as "name=[name]&amp;nick=[nick]&amp;email=[email]&amp;sig=[signature]"</returns>
        internal HttpCookie MakeCookie(HttpApplication _app) 
        {
            HttpCookie cookie = new HttpCookie(GetCookieName());

            if (!IsAuthenticated) 
                return null;

            StringBuilder cookieBuilder = new StringBuilder();
            cookieBuilder.AppendFormat("email={0}&name={1}&nick={2}&ts={3}&sig={4}", 
                _app.Server.UrlEncode(email),
                _app.Server.UrlEncode(name),
                _app.Server.UrlEncode(nick),
                _app.Server.UrlEncode(ts.ToString()),
                _app.Server.UrlEncode(sig));
            
            cookie.Value = cookieBuilder.ToString();

            int expiration = GetCookieExpiration();
            if (expiration > 0) 
            {
                DateTime now = DateTime.Now;
                cookie.Expires = now.AddSeconds(expiration);
            } 
            return cookie;
        }


        /// <summary>Validate whether the user is authenticated.</summary>
        private void CheckSignature() 
        {
            // http://en.wikipedia.org/wiki/DSA

            // rebuild the message and verify it's signature
            string message = email + "::" + name + "::" + nick + "::" + ts;
        
            // fetch the TypeKey public DSA key
            DSACryptoServiceProvider dsaCrypto = new DSACryptoServiceProvider();
            dsaCrypto.ImportParameters(GetTypekeyPublicDsaKey());           

            // hash the message
            UTF8Encoding utf8 = new UTF8Encoding();
            byte[] messageHashBytes = utf8.GetBytes(message);

            // convert sig from "<RBase64>:<SBase54>" to RS
            char[] columnSplitter = {':'};
            string[] strRandS = sig.Split(columnSplitter);
            if (strRandS.Length != 2) 
            {
                return;
            }
            string strBase64R = strRandS[0];
            string strBase64S = strRandS[1];
            byte[] RBytes = Convert.FromBase64String(strBase64R.Replace(" ","+"));
            byte[] SBytes = Convert.FromBase64String(strBase64S.Replace(" ","+"));
            if (RBytes.Length != 20 ||
                SBytes.Length != 20) 
            {
                throw new Exception("Signature isn't 40 bytes in size");
            }
            byte[] sigBytes = new byte[40];
            Array.Copy(RBytes, sigBytes, 20);
            Array.Copy(SBytes, 0, sigBytes, 20, 20);

            // Verify the signature
            if (dsaCrypto.VerifyData(messageHashBytes, sigBytes)) 
            {
                // woohoo!!!
                loggedin = true;
            }
        }

        
        private DSAParameters GetTypekeyPublicDsaKey() 
        {
            // is the DSAParameters object already cached?
            object cached = app.Context.Cache[PUBKEY_CACHE_NAME];
            if (cached != null) 
            {
                try 
                {
                    return (DSAParameters) cached;
                } 
                catch {}
            }


            // fetch the TypeKey's public DSA key
            string key = GetTypekeyPublicDsaKeyString();
            
            // parse key (each component is decimal)
            string strP = "";
            string strG = "";
            string strQ = "";
            string strY = "";
            char[] spaceSplitter = {' '};
            char[] equalSplitter = {'='};
            string[] subKeys = key.Split(spaceSplitter);

            foreach (string subKey in subKeys) 
            {
                string[] pairs = subKey.Split(equalSplitter);
                if (pairs.Length == 2) 
                {  
                    switch (pairs[0].ToLower()) 
                    {
                        case "p":
                            strP = pairs[1];
                            break;
                        case "g":
                            strG = pairs[1];
                            break;
                        case "q":
                            strQ = pairs[1];
                            break;
                        case "pub_key":
                            strY = pairs[1];
                            break;
                    }
                }
            }

            const int base10 = 10;
            BigInteger biP = new BigInteger(strP, base10);
            BigInteger biG = new BigInteger(strG, base10);
            BigInteger biQ = new BigInteger(strQ, base10);
            BigInteger biY = new BigInteger(strY, base10);

            // store key in DSAParameters
            DSAParameters dsaParams = new DSAParameters();
            dsaParams.P = biP.getBytes();
            dsaParams.G = biG.getBytes();
            dsaParams.Q = biQ.getBytes();
            dsaParams.Y = biY.getBytes();

            // cache the final DSAParameters object
            app.Context.Cache.Add(PUBKEY_CACHE_NAME, dsaParams, null, DateTime.Now.AddSeconds(GetKeyCacheTimeout()),
                TimeSpan.Zero, CacheItemPriority.NotRemovable, null);

            return dsaParams;
        }

        /// <summary>Get the current url, cleaned of any TypeKey specific parameters.</summary>
        /// <returns>The cleaned current url, as a string.</returns>
        /// <remarks>The querystring parameters that TypeKey uses are ts, name, nick, email and sig.</remarks>
        public string GetCleanUrl() 
        {
            return GetCleanUrl(app.Request.Url);
        }

        /// <summary>Clean a dirty url of any TypeKey specific parameters.</summary>
        /// <param name="dirtyUrl">The Uri that needs cleaning.</param>
        /// <returns>The cleaned url, as a string.</returns>
        /// <remarks>The querystring parameters that TypeKey uses are ts, name, nick, email and sig.</remarks>
        public string GetCleanUrl(Uri dirtyUrl) 
        {
            bool first = true;
            StringBuilder pathAndQuery = new StringBuilder();

            pathAndQuery.Append(dirtyUrl.AbsolutePath);
            string dirtyQuery = dirtyUrl.Query;
            if (dirtyQuery.StartsWith("?")) 
            {
                dirtyQuery = dirtyQuery.Remove(0,1);
            }
            NameValueCollection parameters = TypeKeyIdentity.ParseQuerystringFormat(app, dirtyQuery);
            foreach (string key in parameters.AllKeys) 
            {
                if (key == null ||
                    key == QS_EMAIL ||
                    key == QS_NAME ||
                    key == QS_NICK ||
                    key == QS_TS ||
                    key == QS_LOGOUT ||
                    key == QS_SIG) 
                {
                    continue;
                }

                char separator = '&';
                if (first) 
                {
                    separator = '?';
                    first = false;
                }

                pathAndQuery.AppendFormat("{0}{1}={2}", 
                    separator,
                    app.Server.UrlEncode(key), 
                    app.Server.UrlEncode(parameters[key]));
             
            }

            Uri cleanedUrl = new Uri(dirtyUrl, pathAndQuery.ToString(), true);
            return cleanedUrl.ToString();
        }

        #endregion
    }
}
