using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using WMPLib;

namespace MediaTest
{
    enum StartZone 
    {
        Center,
        TopLeft,
        Top,
        TopRight,
        Right,
        BottomRight,
        Bottom,
        BottomLeft,
        Left
    }

    public enum Mode 
    {
        None,
        Move,
        Menu
    }

    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public class Form1 : System.Windows.Forms.Form
    {
        
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;
        private MenuForm menuForm;
        private int startX, startY; // Used in the Move mode
        private StartZone startZone = StartZone.Center;
        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1; // Used in the Move mode
        public Mode _mode;
		
        public Mode mode 
        {
            get { return _mode; }
            set 
            {
                if (_mode == value) 
                {
                    return;
                }
                Console.WriteLine("entering {0} mode", value);
                switch (value) 
                {
                    case Mode.Move:
                        axWindowsMediaPlayer1.MouseUpEvent -= 
                            new AxWMPLib._WMPOCXEvents_MouseUpEventHandler(MenuMode_MouseUp);
                        axWindowsMediaPlayer1.MouseDownEvent +=
                            new AxWMPLib._WMPOCXEvents_MouseDownEventHandler(MoveMode_MouseDown);
                        axWindowsMediaPlayer1.MouseMoveEvent +=
                            new AxWMPLib._WMPOCXEvents_MouseMoveEventHandler(MoveMode_MouseMove);
                        axWindowsMediaPlayer1.MouseUpEvent +=
                            new AxWMPLib._WMPOCXEvents_MouseUpEventHandler(MoveMode_MouseUp);

                        break;
                    case Mode.Menu:
                        axWindowsMediaPlayer1.MouseUpEvent += 
                            new AxWMPLib._WMPOCXEvents_MouseUpEventHandler(MenuMode_MouseUp);
                        axWindowsMediaPlayer1.MouseDownEvent -=
                            new AxWMPLib._WMPOCXEvents_MouseDownEventHandler(MoveMode_MouseDown);
                        axWindowsMediaPlayer1.MouseMoveEvent -=
                            new AxWMPLib._WMPOCXEvents_MouseMoveEventHandler(MoveMode_MouseMove);
                        axWindowsMediaPlayer1.MouseUpEvent -=
                            new AxWMPLib._WMPOCXEvents_MouseUpEventHandler(MoveMode_MouseUp);
                        break;
                }
                _mode = value;
            }
        }


        public Form1()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();
            //
            // TODO: Add any constructor code after InitializeComponent call
            //
            //axWindowsMediaPlayer1.EnableFullScreenControls = true;
            //axWindowsMediaPlayer1.AutoSize = true;
            axWindowsMediaPlayer1.Width = this.Width;
            axWindowsMediaPlayer1.Height = this.Height;
            //axWindowsMediaPlayer1.VideoBorderWidth = 0;

            this.Resize += new EventHandler(form_Resize);

            menuForm = new MenuForm(this);
            mode = Mode.Move;
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if (components != null) 
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }

		#region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            this.SuspendLayout();
            // 
            // axWindowsMediaPlayer1
            // 
            this.axWindowsMediaPlayer1.Enabled = true;
            this.axWindowsMediaPlayer1.Location = new System.Drawing.Point(0, 0);
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            this.axWindowsMediaPlayer1.Size = new System.Drawing.Size(552, 408);
            this.axWindowsMediaPlayer1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(552, 405);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            this.ResumeLayout(false);

        }
		#endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() 
        {
            Application.Run(new Form1());
        }

        private void MenuMode_MouseUp(object sender, AxWMPLib._WMPOCXEvents_MouseUpEvent e)
        {
            if ((e.nButton & 2) != 0)
            { // Right button
                Console.WriteLine("right button up (menu mode)");
                if (menuForm.Visible) 
                {
                    menuForm.MyHide();
                    mode = Mode.Move;
                    Console.WriteLine("hide");
                }
            }
			
            return;
        }

        private void MoveMode_MouseDown(object sender, AxWMPLib._WMPOCXEvents_MouseDownEvent e)
        {
            if ((e.nButton & 1) != 0)
            { // Left click
                startX = e.fX;
                startY = e.fY;

                Console.WriteLine("down");
                // TODO: depending on the location of the click, set the startZone
                startZone = FindZone(e.fX, e.fY);
                SetCursor(startZone);
            }

            return; 
        }

        private void MoveMode_MouseUp(object sender, AxWMPLib._WMPOCXEvents_MouseUpEvent e)
        {
            if ((e.nButton & 1) != 0)
            { // Left button
                SetCursor(FindZone(e.fX, e.fY));
            }
            if ((e.nButton & 2) != 0)
            { // Right button
                Console.WriteLine("right button up (move mode)");
                if (!menuForm.Visible)
                {
                    menuForm.Location = this.Location;
                    menuForm.Size = this.Size;
                    menuForm.Show(new Point(e.fX, e.fY));
                    menuForm.Location = this.Location;
                    menuForm.Size = this.Size;
                    Console.WriteLine("show menu");
                }
                // Go into Menu mode
                e.nButton = 0;
                mode = Mode.Menu;
                // bug!!!
                // it seems like the current "mouse up" event gets passed to the 
                //      handlers that are added when we switch mode (when the video is running) :(
                //      ... so the menu disappears...
            }

            return; 
        }

        private void MoveMode_MouseMove(object sender, AxWMPLib._WMPOCXEvents_MouseMoveEvent e)
        {
            if ((e.nButton & 1) != 0) 
            { // Left button
                System.Drawing.Point p = this.Location;
                System.Drawing.Size s = this.Size;
                SetCursor(startZone);

                switch (startZone) 
                {
                    case StartZone.Center:
                        p.X += (e.fX - startX);
                        p.Y += (e.fY - startY);
                        if (Math.Abs(e.fX - startX) > 0 || Math.Abs(e.fY - startY) > 0) 
                        {
                            this.Location = p;
                        }
                        break;

                    case StartZone.Top:
                        p.Y += (e.fY - startY);
                        s.Height -= (e.fY - startY);
                        if (e.fY > startY)
                        {
                            this.Size = s;
                            this.Location = p;
                        }
                        else if (e.fY < startY)
                        {
                            this.Location = p;
                            this.Size = s;
                        }
                        break;

                    case StartZone.TopRight:
                        p.Y += (e.fY - startY);
                        s.Height -= (e.fY - startY);
                        s.Width += (e.fX - startX);
                        this.Size = s;
                        this.Location = p;
                        startX = e.fX;
                        break;

                    case StartZone.Right:
                        s.Width += (e.fX - startX);
                        this.Size = s;
                        startX = e.fX;
                        break;

                    case StartZone.BottomRight:
                        s.Height += (e.fY - startY);
                        s.Width += (e.fX - startX);
                        this.Size = s;
                        startY = e.fY;
                        startX = e.fX;
                        break;

                    case StartZone.Bottom:
                        s.Height += (e.fY - startY);
                        if (e.fY - startY > 0) 
                        {
                            this.Size = s;
                            startY = e.fY;
                        } 
                        else if (e.fY - startY < 0) 
                        {
                            startY = e.fY;
                            this.Size = s;
                        }
                        break;

                    case StartZone.BottomLeft:
                        s.Height += (e.fY - startY);
                        p.X += (e.fX - startX);
                        s.Width -= (e.fX - startX);
                        startY = e.fY;
                        this.Location = p;
                        this.Size = s;

                        break;

                    case StartZone.Left:
                        p.X += (e.fX - startX);
                        s.Width -= (e.fX - startX);
                        if (e.fX > startX) 
                        {
                            this.Size = s;
                            this.Location = p;
                        }
                        else if (e.fX < startX) 
                        {
                            this.Location = p;
                            this.Size = s;
                        }
                        break;
					
                    case StartZone.TopLeft:
                        p.X += (e.fX - startX);
                        p.Y += (e.fY - startY);
                        s.Width -= (e.fX - startX);
                        s.Height -= (e.fY - startY);
                        this.Size = s;
                        this.Location = p;
                        break;

                    default:
                        break;
                }
            }
            else if (e.nButton == 0) 
            {
                // Depending on position show a different cursor
                StartZone curZone = FindZone(e.fX, e.fY);
                SetCursor(curZone);
            }

            return; 
        }

        private void form_Resize(object sender, System.EventArgs e)
        {
            axWindowsMediaPlayer1.Width = this.Width;
            axWindowsMediaPlayer1.Height = this.Height;
        }

        public void Play() 
        {
            axWindowsMediaPlayer1.Ctlcontrols.play();
        }

        public void Pause() 
        {
            axWindowsMediaPlayer1.Ctlcontrols.pause();
        }

        public void OpenFile() 
        {            

            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Media Files|*.mpg;*.avi;*.wma;*.mov;*.wav;*.mp2;*.mp3|All Files|*.*";

            if (DialogResult.OK == openFileDialog.ShowDialog())
            {
                axWindowsMediaPlayer1.URL = openFileDialog.FileName;
            }

            //axWindowsMediaPlayer1.Open("c:\\burn\\Stigmata.avi");
        }

        public void CloseFile() 
        {
            // TODO: close movie file
            axWindowsMediaPlayer1.Ctlcontrols.stop();
        }

        private void SetCursor(StartZone zone) 
        {
            switch (zone) 
            {
                case StartZone.Top:
                case StartZone.Bottom:
                    Cursor.Current = Cursors.SizeNS;
                    break;
                case StartZone.Left:
                case StartZone.Right:
                    Cursor.Current = Cursors.SizeWE;
                    break;
                case StartZone.TopLeft:
                case StartZone.BottomRight:
                    Cursor.Current = Cursors.SizeNWSE;
                    break;
                case StartZone.TopRight:
                case StartZone.BottomLeft:
                    Cursor.Current = Cursors.SizeNESW;
                    break;
                case StartZone.Center:
                    Cursor.Current = Cursors.SizeAll;
                    break;
            }
        }

        private StartZone FindZone(int x, int y) 
        {
            // depending on the cursor
            int height = this.Size.Height;
            int width = this.Size.Width;

            int horIndex = 0;
            if (3 * x > 2 * width) 
            {
                horIndex = 2;
            } 
            else if (3 * x > width)
            {
                horIndex = 1;
            }

            int verIndex = 0;
            if (3 * y > 2 * height) 
            {
                verIndex = 2;
            } 
            else if (3 * y > height)
            {
                verIndex = 1;
            }

            return zones[verIndex, horIndex];
        }
        static StartZone[,]zones = new StartZone[3,3] 
            {
                    { StartZone.TopLeft, StartZone.Top, StartZone.TopRight }, 
             { StartZone.Left, StartZone.Center, StartZone.Right },
             { StartZone.BottomLeft, StartZone.Bottom, StartZone.BottomRight}};

    }
}
