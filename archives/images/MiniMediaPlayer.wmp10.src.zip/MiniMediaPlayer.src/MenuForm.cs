using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MediaTest
{
    enum PlayState 
    {
        Empty,
        Started,
        Paused
    }

    /// <summary>
    /// Summary description for MenuForm.
    /// </summary>
    public class MenuForm : System.Windows.Forms.Form
    {
        private System.Windows.Forms.Button item1;
        private System.Windows.Forms.Button item2;
        private System.Windows.Forms.Button item3;
        private System.Windows.Forms.Button item4;
        private System.Windows.Forms.Button item5;
        private System.Windows.Forms.Button item6;
        private System.Windows.Forms.Button item7;
        private System.Windows.Forms.Button item0;
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.Container components = null;
        private Button[] items;
        private Form1 parentForm;
        private PlayState _playState = PlayState.Empty;
        private Point[] layout;

        private PlayState playState 
        {
            get { return _playState; }
            set 
            {
                switch (value) 
                {
                    case PlayState.Empty:
                        item0.Text = "Open";
                        item7.Text = "Quit";
                        break;
                    case PlayState.Started:
                        item0.Text = "Pause";
                        item7.Text = "Close";
                        break;
                    case PlayState.Paused:
                        item0.Text = "Play";
                        item7.Text = "Close";
                        break;
                    default:
                        return;
                }
                _playState = value;
            }
        }

        public MenuForm(Form1 _parent)
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
            parentForm = _parent;
            items = new Button[8] { item0, item1, item2, item3, item4, item5, item6, item7 };
			
            item0.Click += new EventHandler(OpenPlayPause_Click);
            item7.Click += new EventHandler(CloseQuit_Click);
            playState = PlayState.Empty;

            layout = new Point[8] { new Point(-24, -52), /* Top */
                                      new Point(32, -44),
                                      new Point(40, -12), /* Right */
                                      new Point(32, 20),
                                      new Point(-24, 28), /* Bottom */
                                      new Point(-80, 20),
                                      new Point(-96, -12), /* Left */
                                      new Point(-80, -44) };
            //MyHide();
        }

        public void Show(Point center) 
        {
            // Move all the controls around
            for (int i = 0; i < 8; i++) 
            {
                items[i].Location = new Point(center.X + layout[i].X, center.Y + layout[i].Y);
            }
            parentForm.Refresh();
            //pen, center.X, center.Y, center.X, e.Y);

            Show();
            Refresh();
        }

        public void MyHide() 
        {
            // Trick to make the hidding/showing smoother
            for (int i = 0; i < 8; i++) 
            {
                items[i].Location = new Point(-200, -200);
            }
            Refresh();
            Hide();
            Console.WriteLine("myhide");
            parentForm.mode = Mode.Move;
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if(components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }

		#region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.item1 = new System.Windows.Forms.Button();
            this.item2 = new System.Windows.Forms.Button();
            this.item3 = new System.Windows.Forms.Button();
            this.item4 = new System.Windows.Forms.Button();
            this.item5 = new System.Windows.Forms.Button();
            this.item6 = new System.Windows.Forms.Button();
            this.item7 = new System.Windows.Forms.Button();
            this.item0 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // item1
            // 
            this.item1.BackColor = System.Drawing.SystemColors.Control;
            this.item1.Location = new System.Drawing.Point(200, 56);
            this.item1.Name = "item1";
            this.item1.Size = new System.Drawing.Size(48, 23);
            this.item1.TabIndex = 0;
            this.item1.Text = "Seek";
            // 
            // item2
            // 
            this.item2.BackColor = System.Drawing.SystemColors.Control;
            this.item2.Location = new System.Drawing.Point(208, 88);
            this.item2.Name = "item2";
            this.item2.Size = new System.Drawing.Size(56, 23);
            this.item2.TabIndex = 1;
            this.item2.Text = "Options";
            // 
            // item3
            // 
            this.item3.BackColor = System.Drawing.SystemColors.Control;
            this.item3.Location = new System.Drawing.Point(200, 120);
            this.item3.Name = "item3";
            this.item3.Size = new System.Drawing.Size(48, 23);
            this.item3.TabIndex = 2;
            this.item3.Text = "?";
            // 
            // item4
            // 
            this.item4.BackColor = System.Drawing.SystemColors.Control;
            this.item4.Location = new System.Drawing.Point(144, 128);
            this.item4.Name = "item4";
            this.item4.Size = new System.Drawing.Size(48, 23);
            this.item4.TabIndex = 3;
            this.item4.Text = "?";
            // 
            // item5
            // 
            this.item5.BackColor = System.Drawing.SystemColors.Control;
            this.item5.Location = new System.Drawing.Point(88, 120);
            this.item5.Name = "item5";
            this.item5.Size = new System.Drawing.Size(48, 23);
            this.item5.TabIndex = 4;
            this.item5.Text = "Max";
            // 
            // item6
            // 
            this.item6.BackColor = System.Drawing.SystemColors.Control;
            this.item6.Location = new System.Drawing.Point(72, 88);
            this.item6.Name = "item6";
            this.item6.Size = new System.Drawing.Size(56, 23);
            this.item6.TabIndex = 5;
            this.item6.Text = "Volume";
            // 
            // item7
            // 
            this.item7.BackColor = System.Drawing.SystemColors.Control;
            this.item7.Location = new System.Drawing.Point(88, 56);
            this.item7.Name = "item7";
            this.item7.Size = new System.Drawing.Size(48, 23);
            this.item7.TabIndex = 6;
            this.item7.Text = "Close";
            // 
            // item0
            // 
            this.item0.BackColor = System.Drawing.SystemColors.Control;
            this.item0.Location = new System.Drawing.Point(144, 48);
            this.item0.Name = "item0";
            this.item0.Size = new System.Drawing.Size(48, 23);
            this.item0.TabIndex = 7;
            this.item0.Text = "Play";
            // 
            // MenuForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
            this.ClientSize = new System.Drawing.Size(292, 273);
            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                                                                          this.item0,
                                                                          this.item7,
                                                                          this.item6,
                                                                          this.item5,
                                                                          this.item4,
                                                                          this.item3,
                                                                          this.item2,
                                                                          this.item1});
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MenuForm";
            this.ShowInTaskbar = false;
            this.Text = "MenuForm";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
            this.ResumeLayout(false);

        }
		#endregion

        private void Button_Click(object sender, System.EventArgs e)
        {
		
        }

        private void OpenPlayPause_Click(object sender, System.EventArgs e)
        {
            switch (playState) 
            {
                case PlayState.Empty:
                    this.MyHide();
                    parentForm.OpenFile();
                    playState = PlayState.Started;
                    break;
                case PlayState.Paused:
                    this.MyHide();
                    parentForm.Play();
                    playState = PlayState.Started;
                    break;
                case PlayState.Started:
                    this.MyHide();
                    parentForm.Pause();
                    playState = PlayState.Paused;
                    break;
            }
        }

        private void CloseQuit_Click(object sender, System.EventArgs e)
        {
            switch (playState) 
            {
                case PlayState.Empty:
                    parentForm.Close();
                    break;
                case PlayState.Started:
                case PlayState.Paused:
                    parentForm.CloseFile();
                    playState = PlayState.Empty;
                    break;
            }
        }
    }
}