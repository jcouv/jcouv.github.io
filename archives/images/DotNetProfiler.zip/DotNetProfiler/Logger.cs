using System;

namespace DumkyNamespace 
{
	public class Logger 
	{
		public static void Log() 
		{
			Console.WriteLine("Log!");
		}
	}
}