using System;

public class Hello 
{
	//[STAThread]
	public static void Main(string[] prms) 
	{
		Console.WriteLine("main!");
	}
}

public class Logger 
{
	public static void Log() {
		Console.WriteLine("log!");
	}
}
