

#include "ProfilerCallback.h"


HRESULT CProfilerCallback::JITCompilationStarted(UINT functionId,
												 BOOL fIsSafeToBlock)
{
	wchar_t wszClass[512];
	wchar_t wszMethod[512];

	HRESULT hr = S_OK;

	ClassID classId = 0;
	ModuleID moduleId = 0;
	mdToken tkMethod = 0;
	USES_CONVERSION;

	// Make this a method
	// Only execute for the Main method
	if ( GetMethodNameFromFunctionId( functionId, wszClass, wszMethod ) )
	{
		ProfilerPrintf("JITCompilationStarted: %ls::%ls\n",wszClass,wszMethod);
		if (wcscmp(wszClass, L"Hello") != 0 || wcscmp(wszMethod, L"Main") != 0) {
			goto exit;
		}
	} else {
		ProfilerPrintf( "JITCompilationStarted\n" );
		goto exit;
	}

	// Get the moduleID and tkMethod
	hr = m_pICorProfilerInfo->GetFunctionInfo(functionId, &classId, &moduleId, &tkMethod );
	if (FAILED(hr))
	{ goto exit; }

	// Get the metadata import
	IMetaDataImport* pMetaDataImport = NULL;
	hr = m_pICorProfilerInfo->GetModuleMetaData(moduleId, ofRead, IID_IMetaDataImport,
		(IUnknown** )&pMetaDataImport);
	if (FAILED(hr))
	{ goto exit; }

	// JCOUV make this a method
	// Get the token for the Logger class
	mdTypeDef tkLogger = 0;
	hr = pMetaDataImport->FindTypeDefByName(L"Logger", 0, &tkLogger);
	if (FAILED(hr))
	{ goto exit; }

	// Get all the methods of the Logger class and find the token for the Log method
	mdMethodDef tkLog = 0;
	HCORENUM enr = 0; // enumerator
	
	// Bunch of method tokens
	const int siz = 1; // size of arrays
	mdMethodDef rMethodToks[siz]; // array to hold returned bodies
	ULONG count; // count of tokens returned

	hr = pMetaDataImport->EnumMethodsWithName(&enr, tkLogger, L"Log", rMethodToks, siz, &count);
	if (FAILED(hr)) { goto exit; }
	// assumption: there is only one "Log" method on the Logger
	if (count == 1) {
		tkLog = rMethodToks[0];
	}

	ProfilerPrintf("\nLog token: %08X\n", tkLog);
	pMetaDataImport->CloseEnum(enr);
	pMetaDataImport->Release();
/*
	//
	// Metadata modification
	//
	IMetaDataEmit* pMetaDataEmit = NULL;
	IMetaDataAssemblyEmit* pMetaDataAssemblyEmit = NULL;
	
	hr = m_pICorProfilerInfo->GetModuleMetaData(
				moduleId, ofRead | ofWrite, IID_IMetaDataEmit,
				(IUnknown** )&pMetaDataEmit );
	if (FAILED(hr)) { goto exit; }
	Check(pMetaDataEmit->QueryInterface(IID_IMetaDataAssemblyEmit,
		(void**)&pMetaDataAssemblyEmit));

	ASSEMBLYMETADATA amd;
	ZeroMemory(&amd, sizeof(amd));
	amd.usMajorVersion = 1;
	amd.usMinorVersion = 0;
	amd.usBuildNumber = 3300;
	amd.usRevisionNumber = 0;
	BYTE keyECMA[] = { 0xB7, 0x7A, 0x5C, 0x56, 0x19, 0x34, 0xE0,
		0x89 };
	hr = pMetaDataAssemblyEmit->DefineAssemblyRef(keyECMA,
			sizeof(keyECMA),
			L"mscorlib", &amd, NULL, 0, 0, &tkMSCORLIB);

	hr = pMetaDataEmit->DefineTypeRefByName(tkMSCORLIB,
			L"System.Console", &tkConsole);

	BYTE Sig_void_String[] = { 
		0, // IMAGE_CEE_CS_CALLCONV_DEFAULT
			0x1, // argument count
			0x1, // ret = ELEMENT_TYPE_VOID
			0xe, // arg1 = ELEMENT_TYPE_STRING
	}; 

	hr = pMetaDataEmit->DefineMemberRef(tkConsole,
		L"WriteLine",
		Sig_void_String, sizeof(Sig_void_String),
		&tkWriteLine);

*/
	//
	// IL modification
	//

#include <pshpack1.h>
	struct {
		BYTE call; DWORD method_token;
	} ILCode;
#include <poppack.h>

	ILCode.call = 0x28;
	ILCode.method_token = tkLog;

	InsertIL(moduleId, tkMethod, (BYTE*) &ILCode, sizeof(ILCode));


exit:
	return hr;
}





HRESULT CProfilerCallback::InsertIL(ModuleID moduleId, mdToken tkMethod, BYTE* pbNewIL, int iNewILLen) {
	HRESULT hr = S_OK;

	//
	// Get the existing IL
	//
	LPCBYTE pMethodHeader = NULL;
	ULONG iMethodSize = 0;
	hr = m_pICorProfilerInfo->GetILFunctionBody(moduleId, tkMethod, &pMethodHeader, &iMethodSize);
	if (FAILED(hr))
	{ goto exit; }

	//
	// Print the existing IL
	//
	IMAGE_COR_ILMETHOD* pMethod = (IMAGE_COR_ILMETHOD*)pMethodHeader;
	COR_ILMETHOD_FAT* fatImage = (COR_ILMETHOD_FAT*)&pMethod->Fat;

	if(!fatImage->IsFat()) {
		goto exit;
	}

	ProfilerPrintf("\n");
	ProfilerPrintIL(fatImage);


	//
	// Get the IL Allocator
	//
	IMethodMalloc* pIMethodMalloc = NULL;
	IMAGE_COR_ILMETHOD* pNewMethod = NULL;
	hr = m_pICorProfilerInfo->GetILFunctionBodyAllocator(moduleId, &pIMethodMalloc);
	if (FAILED(hr))
	{ goto exit; }

	//
	// Allocate IL space and copy the IL in it
	//
	pNewMethod = (IMAGE_COR_ILMETHOD*) pIMethodMalloc->Alloc(iMethodSize+iNewILLen);
	if (pNewMethod == NULL)
	{ goto exit; }
	COR_ILMETHOD_FAT* newFatImage = (COR_ILMETHOD_FAT*)&pNewMethod->Fat;


	//
	// Modify IL
	//
	// Copy the header
	memcpy((BYTE*)newFatImage, (BYTE*)fatImage, fatImage->Size * sizeof(DWORD));

	// Add a call to "Log"
	memcpy(newFatImage->GetCode(), pbNewIL, iNewILLen);

	// Copy the remaining of the method
	memcpy(newFatImage->GetCode() + iNewILLen,
		fatImage->GetCode(),
		fatImage->CodeSize);


	// Update the code size
	newFatImage->CodeSize += iNewILLen;


	// Print modified IL
	ProfilerPrintf("\n");
	ProfilerPrintIL(newFatImage);

	// Push IL back in
	hr = m_pICorProfilerInfo->SetILFunctionBody(moduleId, tkMethod, (LPCBYTE) pNewMethod);
	if (FAILED(hr))
	{ goto exit; }

	pIMethodMalloc->Release();
exit:
	return hr;
}



HRESULT CProfilerCallback::JITCompilationFinished(UINT functionId,
												  HRESULT hrStatus, BOOL fIsSafeToBlock)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::JITCachedFunctionSearchStarted(UINT functionId,
														  BOOL * pbUseCachedFunction)
{
	
	__asm int 3;
	ProfilerPrintf("JIT CACHE LOOKUP !!!!!!!!\n");
	/*
	wchar_t wszClass[512];
	wchar_t wszMethod[512];

	if ( GetMethodNameFromFunctionId( functionId, wszClass, wszMethod ) )
	{
	ProfilerPrintf( "JITCachedFunctionSearchStarted: %ls::%ls\n",
	wszClass, wszMethod );
	}
	else
	{
	ProfilerPrintf( "JITCachedFunctionSearchStarted\n" );
	}
	
	// Force JIT'ting to occur
	*pbUseCachedFunction = FALSE;
	*/
	return S_OK;
}
HRESULT CProfilerCallback::JITCachedFunctionSearchFinished(UINT functionId,
														   COR_PRF_JIT_CACHE result)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::JITFunctionPitched(UINT functionId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::JITInlining(UINT callerId, UINT calleeId,
									   BOOL * pfShouldInline)
{
	/*
	if (pfShouldInline == NULL)
	return E_POINTER;
	*/  
	return E_NOTIMPL;
}

void CProfilerCallback::ProfilerPrintIL(COR_ILMETHOD_FAT* fatImage)
{
	ProfilerPrintf("Flags: %X\n", fatImage->Flags);
	ProfilerPrintf("Size: %X\n", fatImage->Size);
	ProfilerPrintf("MaxStack: %X\n", fatImage->MaxStack);
	ProfilerPrintf ("CodeSize: %X\n", fatImage->CodeSize);
	ProfilerPrintf("LocalVarSigTok: %X\n", fatImage->LocalVarSigTok);
	byte* codeBytes = fatImage->GetCode();

	for(ULONG i = 0; i < fatImage->CodeSize; i++) {
		if(codeBytes[i] > 0x0F) {
			ProfilerPrintf("codeBytes[%u] = 0x%X;\n", i, codeBytes[i]);
		} else {
			ProfilerPrintf("codeBytes[%u] = 0x0%X;\n", i, codeBytes[i]);
		}
	}
}

PCCOR_SIGNATURE CProfilerCallback::PrettyPrintType(PCCOR_SIGNATURE typePtr,			// type to convert, 	
												   IMetaDataImport *pIMDI)				// ptr to IMDInternal class with ComSig
{
	mdToken		tk;	
	const char	*str;	
	WCHAR rcname[MAX_CLASS_NAME];
	bool		isValueArray;
	HRESULT		hr;

	switch(*typePtr++) 
	{	
	case ELEMENT_TYPE_VOID			:	
		str = "void"; goto APPEND;	
	case ELEMENT_TYPE_BOOLEAN		:	
		str = "bool"; goto APPEND;	
	case ELEMENT_TYPE_CHAR			:	
		str = "wchar"; goto APPEND; 
	case ELEMENT_TYPE_I1			:	
		str = "int8"; goto APPEND;	
	case ELEMENT_TYPE_U1			:	
		str = "unsigned int8"; goto APPEND; 
	case ELEMENT_TYPE_I2			:	
		str = "int16"; goto APPEND; 
	case ELEMENT_TYPE_U2			:	
		str = "unsigned int16"; goto APPEND;	
	case ELEMENT_TYPE_I4			:	
		str = "int32"; goto APPEND; 
	case ELEMENT_TYPE_U4			:	
		str = "unsigned int32"; goto APPEND;	
	case ELEMENT_TYPE_I8			:	
		str = "int64"; goto APPEND; 
	case ELEMENT_TYPE_U8			:	
		str = "unsigned int64"; goto APPEND;	
	case ELEMENT_TYPE_R4			:	
		str = "float32"; goto APPEND;	
	case ELEMENT_TYPE_R8			:	
		str = "float64"; goto APPEND;	
	case ELEMENT_TYPE_U 			:	
		str = "unsigned int"; goto APPEND;	 
	case ELEMENT_TYPE_I 			:	
		str = "int"; goto APPEND;	 
	case 0x1a /* obsolete */    	:	
		str = "float"; goto APPEND;  
	case ELEMENT_TYPE_OBJECT		:	
		str = "class System.Object"; goto APPEND;	 
	case ELEMENT_TYPE_STRING		:	
		str = "class System.String"; goto APPEND;	 
	case ELEMENT_TYPE_TYPEDBYREF		:	
		str = "refany"; goto APPEND;	
APPEND: 
		ProfilerPrintf(str);
		break;	

	case ELEMENT_TYPE_VALUETYPE	:	
		str = "value class ";	
		goto DO_CLASS;	
	case ELEMENT_TYPE_CLASS 		:	
		str = "class "; 
		goto DO_CLASS;	

DO_CLASS:
		typePtr += CorSigUncompressToken(typePtr, &tk);
		ProfilerPrintf(str);
		rcname[0] = 0;
		str = "test";//rcname;

		if (TypeFromToken(tk) == mdtTypeRef)
			hr = pIMDI->GetTypeRefProps(tk, 0, rcname, NumItems(rcname), 0);
		else if (TypeFromToken(tk) == mdtTypeDef)
		{
			hr = pIMDI->GetTypeDefProps(tk, rcname, NumItems(rcname), 0,
				0, 0);
		}
		else
		{
			_ASSERTE(!"Unknown token type encountered in signature.");
			str = "<UNKNOWN>";
		}

		ProfilerPrintf("%s", str);	
		break;	

	case ELEMENT_TYPE_SZARRAY	 :	 
		typePtr = PrettyPrintType(typePtr, pIMDI); 
		ProfilerPrintf("[]");
		break;
	case 0x17 /* obsolete */	:	
		isValueArray = true; goto DO_ARRAY;
DO_ARRAY:
		{	
			typePtr = PrettyPrintType(typePtr, pIMDI); 
			unsigned bound = CorSigUncompressData(typePtr); 

			if (isValueArray)
				ProfilerPrintf(" value");

			ProfilerPrintf("[%d]", bound);	
		} break;	
	case 0x1e /* obsolete */		:
		typePtr = PrettyPrintType(typePtr, pIMDI); 
		ProfilerPrintf("[?]");
		break;
	case ELEMENT_TYPE_ARRAY		:	
		{	
			typePtr = PrettyPrintType(typePtr, pIMDI); 
			unsigned rank = CorSigUncompressData(typePtr);	
			// TODO what is the syntax for the rank 0 case? 
			if (rank == 0) 
			{
				ProfilerPrintf("[??]");
			}
			else 
			{
				_ASSERTE(rank != 0);	
				int* lowerBounds = (int*) alloca(sizeof(int)*2*rank);	
				int* sizes		 = &lowerBounds[rank];	
				memset(lowerBounds, 0, sizeof(int)*2*rank); 

				unsigned numSizes = CorSigUncompressData(typePtr);	
				_ASSERTE(numSizes <= rank); 
				for(unsigned i =0; i < numSizes; i++)	
					sizes[i] = CorSigUncompressData(typePtr);	

				unsigned numLowBounds = CorSigUncompressData(typePtr);	
				_ASSERTE(numLowBounds <= rank); 
				for(i = 0; i < numLowBounds; i++)	
					lowerBounds[i] = CorSigUncompressData(typePtr); 

				ProfilerPrintf("[");	
				for(i = 0; i < rank; i++)	
				{	
					if (sizes[i] != 0 && lowerBounds[i] != 0)	
					{	
						if (lowerBounds[i] == 0)	
							ProfilerPrintf("%i", sizes[i]);	
						else	
						{	
							ProfilerPrintf("%i", lowerBounds[i]);	
							ProfilerPrintf("...");	
							if (sizes[i] != 0)	
								ProfilerPrintf("%i", lowerBounds[i] + sizes[i] + 1);	
						}	
					}	
					if (i < rank-1) 
						ProfilerPrintf(",");	
				}	
				ProfilerPrintf("]");  
			}
		} break;	

	case 0x13 /* obsolete */        :   
		ProfilerPrintf("!");  
		ProfilerPrintf("%d", CorSigUncompressData(typePtr));
		break;
		// Modifiers or depedant types  
	case ELEMENT_TYPE_PINNED	:
		str = " pinned"; goto MODIFIER;	
		str = "*"; goto MODIFIER;   
	case ELEMENT_TYPE_BYREF         :   
		str = "&"; goto MODIFIER;   
MODIFIER:
		typePtr = PrettyPrintType(typePtr, pIMDI); 
		ProfilerPrintf(str);	
		break;	

	default:	
	case ELEMENT_TYPE_SENTINEL		:	
	case ELEMENT_TYPE_END			:	
		_ASSERTE(!"Unknown Type");	
		return(typePtr);	
		break;	
	}	
	return(typePtr);	
} // static PCCOR_SIGNATURE PrettyPrintType()

void CProfilerCallback::PrettyPrintSig(PCCOR_SIGNATURE typePtr,			// type to convert, 	
									   unsigned	typeLen,				// length of type
									   const WCHAR	*name,				// can be "", the name of the method for this sig	
									   IMetaDataImport *pIMDI) 			// Import api to use.
{
	unsigned numArgs;	
	PCCOR_SIGNATURE typeEnd = typePtr + typeLen;
	USES_CONVERSION;

	if (name != 0)						// 0 means a local var sig	
	{
		// get the calling convention out	
		unsigned callConv = CorSigUncompressData(typePtr);	

		if (isCallConv(callConv, IMAGE_CEE_CS_CALLCONV_FIELD))
		{
			PrettyPrintType(typePtr, pIMDI);	
			if (name != 0 && *name != 0)	
			{	
				ProfilerPrintf(" ");
				ProfilerPrintf(W2A(name));
			}	
			return;	
		}

		if (callConv & IMAGE_CEE_CS_CALLCONV_HASTHIS)
			ProfilerPrintf("instance ");

		static CHAR* callConvNames[8] = 
		{	
			"", 
				"unmanaged cdecl ", 
				"unmanaged stdcall ",	
				"unmanaged thiscall ",	
				"unmanaged fastcall ",	
				"vararg ",	 
				"<error> "	 
				"<error> "	 
		};
		ProfilerPrintf("%s", callConvNames[callConv & 7]);

		numArgs = CorSigUncompressData(typePtr);	
		// do return type	
		typePtr = PrettyPrintType(typePtr, pIMDI); 

	}
	else	
		numArgs = CorSigUncompressData(typePtr);	

	if (name != 0 && *name != 0)	
	{	
		ProfilerPrintf(" ");
		ProfilerPrintf(W2A(name));	
	}	
	ProfilerPrintf("(");

	bool needComma = false;
	while(typePtr < typeEnd) 
	{
		if (*typePtr == ELEMENT_TYPE_SENTINEL) 
		{
			if (needComma)
				ProfilerPrintf(",");
			ProfilerPrintf("...");
			typePtr++;
		}
		else 
		{
			if (numArgs <= 0)
				break;
			if (needComma)
				ProfilerPrintf(",");	
			typePtr = PrettyPrintType(typePtr, pIMDI); 
			--numArgs;	
		}
		needComma = true;
	}
	ProfilerPrintf(")");

	return;
} // LPCWSTR PrettyPrintSig()


