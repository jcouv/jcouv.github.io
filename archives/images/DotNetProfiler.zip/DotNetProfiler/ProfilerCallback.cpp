#define WIN32_LEAN_AND_MEAN // Exclude rarely-used stuff from Windows headers

#include "ProfilerCallback.h"

//====================================================
ULONG CProfilerCallback::AddRef()
{
	return S_OK;
}
ULONG CProfilerCallback::Release()
{
	return S_OK;
}
HRESULT CProfilerCallback::QueryInterface( REFIID riid, void **ppInterface )
{
	return E_NOTIMPL;
}
//====================================================

HRESULT CProfilerCallback::Initialize(IUnknown * pICorProfilerInfoUnk )
{
	GetInititializationParameters();

	if ( m_bBreakOnInitialize ) // Set DN_PROFILER_BREAK environ var to "1"
		__asm int 3

		// Get the ICorProfilerInfo interface we need, and stuff it away in
		// a member variable.
		HRESULT hr =
		pICorProfilerInfoUnk->QueryInterface( IID_ICorProfilerInfo,
		(LPVOID *)&m_pICorProfilerInfo );
	if ( FAILED(hr) )
		return E_INVALIDARG;

	// Indicate which events we're interested in.
	// See GetInititializationParameters
	m_pICorProfilerInfo->SetEventMask( m_dwEventMask );

	// Open the file that we'll write out output to
	m_pOutFile = fopen( m_szOutfileName, "wt" );

	ProfilerPrintf( "Initialize\n" );

	return S_OK;
}

HRESULT CProfilerCallback::Shutdown()
{
	ProfilerPrintf( "Shutdown\n" );
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::AppDomainCreationStarted(UINT appDomainId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::AppDomainCreationFinished(UINT appDomainId,
													 HRESULT hrStatus)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::AppDomainShutdownStarted(UINT appDomainId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::AppDomainShutdownFinished(UINT appDomainId,
													 HRESULT hrStatus)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::AssemblyLoadStarted(UINT assemblyId)
{   
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::AssemblyLoadFinished(UINT assemblyId,
												HRESULT hrStatus)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::AssemblyUnloadStarted(UINT assemblyId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::AssemblyUnloadFinished(UINT assemblyId,
												  HRESULT hrStatus)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ModuleLoadStarted(UINT moduleId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ModuleLoadFinished(UINT moduleId, HRESULT hrStatus)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ModuleUnloadStarted(UINT moduleId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ModuleUnloadFinished(UINT moduleId,
												HRESULT hrStatus)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ModuleAttachedToAssembly(UINT moduleId,
													UINT assemblyId)
{
	return S_OK;
}
HRESULT CProfilerCallback::ClassLoadStarted(UINT classId)
{
	return S_OK;
}
HRESULT CProfilerCallback::ClassLoadFinished(UINT classId, HRESULT hrStatus)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ClassUnloadStarted(UINT classId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ClassUnloadFinished(UINT classId, HRESULT hrStatus)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::FunctionUnloadStarted(UINT functionId)
{
	return E_NOTIMPL;
}

HRESULT CProfilerCallback::ThreadCreated(UINT threadId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ThreadDestroyed(UINT threadId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ThreadAssignedToOSThread(UINT managedThreadId,
													ULONG osThreadId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RemotingClientInvocationStarted()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RemotingClientSendingMessage(GUID * pCookie,
														BOOL fIsAsync)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RemotingClientReceivingReply(GUID * pCookie,
														BOOL fIsAsync)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RemotingClientInvocationFinished()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RemotingServerReceivingMessage(GUID * pCookie,
														  BOOL fIsAsync)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RemotingServerInvocationStarted()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RemotingServerInvocationReturned()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RemotingServerSendingReply(GUID * pCookie,
													  BOOL fIsAsync)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::UnmanagedToManagedTransition(UINT functionId,
														COR_PRF_TRANSITION_REASON reason)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ManagedToUnmanagedTransition(UINT functionId,
														COR_PRF_TRANSITION_REASON reason)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RuntimeSuspendStarted(
	COR_PRF_SUSPEND_REASON suspendReason)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RuntimeSuspendFinished()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RuntimeSuspendAborted()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RuntimeResumeStarted()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RuntimeResumeFinished()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RuntimeThreadSuspended(UINT threadId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::RuntimeThreadResumed(UINT threadId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::MovedReferences(ULONG cMovedObjectIDRanges,
										   UINT oldObjectIDRangeStart[],
										   UINT newObjectIDRangeStart[],
										   ULONG cObjectIDRangeLength[])
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ObjectAllocated(UINT objectId, UINT classId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ObjectsAllocatedByClass(ULONG cClassCount,
												   UINT classIds[],
												   ULONG cObjects[])
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ObjectReferences(UINT objectId, UINT classId,
											ULONG cObjectRefs, UINT objectRefIds[])
{
	return S_OK;
}
HRESULT CProfilerCallback::RootReferences(ULONG cRootRefs, UINT rootRefIds[])
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionThrown(UINT thrownObjectId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionSearchFunctionEnter(UINT functionId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionSearchFunctionLeave()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionSearchFilterEnter(UINT functionId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionSearchFilterLeave()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionSearchCatcherFound(UINT functionId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionOSHandlerEnter(UINT functionId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionOSHandlerLeave(UINT functionId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionUnwindFunctionEnter(UINT functionId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionUnwindFunctionLeave()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionUnwindFinallyEnter(UINT functionId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionUnwindFinallyLeave()
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionCatcherEnter(UINT functionId,UINT objectId)
{
	return E_NOTIMPL;
}
HRESULT CProfilerCallback::ExceptionCatcherLeave()
{
	return E_NOTIMPL;
}

HRESULT CProfilerCallback::COMClassicVTableCreated(ClassID wrappedClassId,
												   REFGUID implementedIID,
												   VOID * pUnk, ULONG cSlots)
{
	return E_NOTIMPL;
}

HRESULT CProfilerCallback::COMClassicVTableDestroyed(ClassID wrappedClassId,
													 REFGUID implementedIID,
													 VOID * pUnk)
{
	return E_NOTIMPL;
}

HRESULT CProfilerCallback::ExceptionCLRCatcherFound(void)
{
	return E_NOTIMPL;
}

HRESULT CProfilerCallback::ExceptionCLRCatcherExecute(void)
{
	return E_NOTIMPL;
}

//=============================================================================
// Helper functions

bool CProfilerCallback::GetMethodNameFromFunctionId(FunctionID functionId,
													LPWSTR wszClass, LPWSTR wszMethod)
{
	mdToken dwToken;
	IMetaDataImport * pIMetaDataImport = 0;

	HRESULT hr = m_pICorProfilerInfo->GetTokenAndMetaDataFromFunction(
		functionId, IID_IMetaDataImport,
		(LPUNKNOWN *)&pIMetaDataImport, &dwToken );
	if ( FAILED(hr) ) return false;

	wchar_t _wszMethod[512];
	DWORD cchMethod = sizeof(_wszMethod)/sizeof(_wszMethod[0]);
	mdTypeDef mdClass;

	hr = pIMetaDataImport->GetMethodProps( dwToken, &mdClass, _wszMethod,
		cchMethod, &cchMethod, 0, 0, 0, 0, 0 );     
	if ( FAILED(hr) ) return false;

	lstrcpyW( wszMethod, _wszMethod );

	wchar_t wszTypeDef[512];
	DWORD cchTypeDef = sizeof(wszTypeDef)/sizeof(wszTypeDef[0]);

	if ( mdClass == 0x02000000 )
		mdClass = 0x02000001;

	hr = pIMetaDataImport->GetTypeDefProps( mdClass, wszTypeDef, cchTypeDef,
		&cchTypeDef, 0, 0 );
	if ( FAILED(hr) ) return false;

	lstrcpyW( wszClass, wszTypeDef );

	pIMetaDataImport->Release();

	//
	// If we were ambitious, we'd save every FunctionID away in a map to avoid
	//  needing to hit the metatdata APIs every time.
	//

	return true;
}

bool CProfilerCallback::GetClassNameFromClassId(ClassID classId,
												LPWSTR wszClass )
{
	ModuleID moduleId;
	mdTypeDef typeDef;

	wszClass[0] = 0;

	HRESULT hr = m_pICorProfilerInfo->GetClassIDInfo( classId, &moduleId,
		&typeDef );
	if ( FAILED(hr) )
		return false;

	if ( typeDef == 0 ) // ::GetClassIDInfo can fail, yet not set HRESULT
	{
		// __asm int 3
		return false;
	}

	IMetaDataImport * pIMetaDataImport = 0;
	hr = m_pICorProfilerInfo->GetModuleMetaData( moduleId, ofRead,
		IID_IMetaDataImport,
		(LPUNKNOWN *)&pIMetaDataImport );
	if ( FAILED(hr) )
		return false;

	if ( !pIMetaDataImport )
		return false;

	wchar_t wszTypeDef[512];
	DWORD cchTypeDef = sizeof(wszTypeDef)/sizeof(wszTypeDef[0]);

	hr = pIMetaDataImport->GetTypeDefProps( typeDef, wszTypeDef, cchTypeDef,
		&cchTypeDef, 0, 0 );
	if ( FAILED(hr) )
		return false;

	lstrcpyW( wszClass, wszTypeDef );

	//
	// If we were ambitious, we'd save the ClassID away in a map to avoid
	//  needing to hit the metatdata APIs every time.
	//

	pIMetaDataImport->Release();

	return true;
}

int CProfilerCallback::ProfilerPrintf(const char *pszFormat, ...)
{
	char szBuffer[1024];
	int retValue;
	va_list argptr;

	va_start( argptr, pszFormat );
	retValue = wvsprintf( szBuffer, pszFormat, argptr );
	va_end( argptr );

	fputs( szBuffer, m_pOutFile );

	return retValue;
}

void CProfilerCallback::GetInititializationParameters()
{
	// Get name of the EXE we're running in the context of.  We're
	// going to dump our output file in the same directory as the EXE
	GetModuleFileName( 0, m_szOutfileName, sizeof(m_szOutfileName) );

	// Overwrite the EXE name with the name of our output file
	char * pszLastSlash = strrchr( m_szOutfileName, '\\' );
	strcpy( pszLastSlash + 1, "DNProfiler.out" );

	// assign reasonable default values to the event mask
	m_dwEventMask = COR_PRF_MONITOR_CLASS_LOADS;
	m_dwEventMask += COR_PRF_MONITOR_MODULE_LOADS;
	m_dwEventMask += COR_PRF_MONITOR_ASSEMBLY_LOADS;

	char szProfilerOptions[256];
	if ( GetEnvironmentVariable( "DN_PROFILER_MASK", szProfilerOptions,
		sizeof(szProfilerOptions) ) )
	{
		m_dwEventMask = strtoul( szProfilerOptions, 0, 16 );
	}

	m_bBreakOnInitialize = false;
	if ( GetEnvironmentVariable( "DN_PROFILER_BREAK", szProfilerOptions,
		sizeof(szProfilerOptions) ) )
	{
		if ( strtoul( szProfilerOptions, 0, 16 ) > 0 )
			m_bBreakOnInitialize = true;
	}
}
