The "dojo-0.3.0-ajax" directory is what comes in the dojo package (stripped down a bit).
The "demo" directory contains the output of the build. That is the directory that you need to access to try "demo.html".
The "src" directory contains what you need to modify and re-compile the Flash files.