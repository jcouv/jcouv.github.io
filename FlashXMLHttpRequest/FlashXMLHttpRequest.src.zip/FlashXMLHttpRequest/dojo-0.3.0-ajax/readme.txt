This is a partial copy of the binary distribution for Dojo. 
"DojoExternalInterface.as" in the flash/flash6 directory is modified (hardcoded path problem).
