"flash6_gateway.swf" is a copy of the one in the dojo distribution. You need a local copy because of a bug in the dojo flash loading code (with a hardcoded path).
