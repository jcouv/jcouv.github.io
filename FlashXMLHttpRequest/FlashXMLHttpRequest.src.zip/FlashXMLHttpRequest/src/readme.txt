The "dojo source files" is a specific directory from a checked out dojo source tree (dojo/src/flash).
"Crossdomain.as" and "HttpConnection.as" are the actual Flash source files, re-used from my previous "Flash4AJAX" project.
