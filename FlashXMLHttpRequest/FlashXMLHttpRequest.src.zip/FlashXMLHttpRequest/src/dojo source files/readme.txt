This is a small subset of a Dojo svn checkout. 
It keeps only the stuff required to build new Flash objects that communicated with Javascript thru DojoExternalInterface.